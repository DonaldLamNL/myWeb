#include <stdio.h>

int main()
{
/*
    運算符：
        賦值運算符：
            1. =
            2. += , -= , *
        算數運算符：
            1. + , - , * , / , %
            2. ++ , --
!important : 
            - 如果是後++ (num++) 則表達式運算之後再+1
            - 如果是前++ (++num) 則表達式運算前就已+1
        關係運算符：
            1. > , < , >= , <=
            2. == , !=
!important : 
            - 0 for false
            - 1 for true
        邏輯運算符：
            1. &&  and
            2. ||  or
            3. !   條件為真，則結果為假，反之亦然
        其他運算符：
            1.按位 : & , | , ~ , ^ 
            2.移 : << , >> , >>> 
    
    運算符的先後順序：
        sizeof() ++ --
        !
        算術運算符
        關係運算符
        &&
        !!
        賦值運算符
*/

    //sizeof
    printf("The spacing of the integer = %dbytes\n",sizeof(int));

    printf("====================================\n");

    int result = 10 > 11 && 10 > 5;
    /*短路運算：
        - 如果使用'&&'和錯誤條件在前置，則後置的條件則不會執行
    */

    printf("%d",result);

    return 0;
}
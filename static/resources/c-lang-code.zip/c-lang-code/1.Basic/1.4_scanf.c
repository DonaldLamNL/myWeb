#include <stdio.h>

int main()
{
    // int num;
    // printf("Please enter a number : ");
    // scanf("%d",&num); //&：取地址
    // printf("which is\n",num);

    printf("===============================\n256");
    int level;
    double maxAtk = 256;
    printf("The player's levels = ");
    scanf("%d",&level);
    maxAtk = maxAtk * (level + 100) / 100;
    printf("The maximum atk = %.2lf",maxAtk);
    return 0;
}

#include<stdio.h>

int main()
{
    /*
        佔位符：打印數據類型
            %d：打印 integer 整數數據類型（int, short） 
            %c：打印 character 字符數據類型 (char)
            %f/ %lf：打印 floating point 浮動點數據類型 (float/ double)
                %.xlf：取小數點 x 個位 （x sig. fig.）
            %x：打印 hex 十六進制數據類型 （x123abc）
    
    
    
    
    */

    double atk = 57.88;
    int atkDistance = 172;
    double HP = 616.28;
    double HPRecover = 7.84;
    printf("名稱：德瑪西亞之力·蓋倫\n");
    printf("傷害：%.2lf(+4.5)\t\t攻擊距離：%d\n",atk,atkDistance);
    printf("護甲：27.536(+3.0)\t\t魔抗：32.1(+1.25)\n");
    printf("生命：%.2lf(+84.25)\t生命恢復：%.2lf(+0.5)\n",HP,HPRecover);
    printf("法力：0.0(+0.0)\t\t\t法力恢復：0.0(+0.0)\n");
    printf("移速：340\t\t\t\t定位：上單 輔助 打野\n");
    printf("點券：450\t\t\t\t金幣：1000\n");
}

#include <stdio.h>

int main(void) {
  int i = 0;
char x[6] = "Hello";
char y[7] = {'H', 'e', 'l', 'l', 'o','@'};
    // '\0' is given autoly

printf("%s\n", y);
while(1){
  printf("%d(%c)\n",y[i], y[i]);
  i++;
  if(i==7)break;
}

/*
    String結構：
        char x[6] = "Hello";
        printf("%s", x);
     OR 
        char x[6] = {'H','e','l','l','o'};
        printf("%s", x);

  **    {'H','e','l','l','o'} == {'H','e','l','l','o','\0'};
        char y[10] = ""; == y[10] = "\0";

    Intilization 聲明&定義:
        char z[] = "Hello";


    函數：
      scanf("%s\n", str);
      printf("You had inputed %s\n", str);



    String其他表達式
      fgets()         //getting a string in this file

      結構：
        fgets(str, 100, stdin);
              to   what  from
*/

  char bye[7] = "Bye bye";
  printf("%s\n", bye);





  return 0;
}
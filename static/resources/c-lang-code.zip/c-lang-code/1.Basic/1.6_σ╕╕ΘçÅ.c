#include <stdio.h>

int main()
{
    /*
        const 常量
        即不可修改的量
        常量名稱通常要全部大寫

        變成分為：code代碼區、data數據區（常量、字符串和static變量）、stack棧區、heap區

        常量是存放在 data 區中
        static int a = 50;
        a 就會存儲在data區中，不會改變，類似constant


    */

//加法表
    int sum;
    int times=0;
    printf("Please enter an Integer = ");
    scanf("%d",&sum);
    for (int i = 0; i < sum; i++)
    {
        for (int j = 0; i < sum; j++)
        {
            if (i + j == sum){
                times++;
                if (times % 2 == 1)
                {                
                    printf("%d + %d = %d\t",i,j,sum);
                }
                else
                {
                    printf("%d + %d = %d\n",i,j,sum);
                }
                break;
            }
        }        
        
    }
    return 0;
}
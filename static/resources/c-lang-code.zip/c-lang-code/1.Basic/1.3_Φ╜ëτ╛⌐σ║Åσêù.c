#include <stdio.h>

int main()
{
    printf("%f",2.5+5/2);

    return 0;
}
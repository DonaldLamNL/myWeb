#include <stdio.h>

int main()
{
    //變量名的首字母：字母/_
    //變量名的其他字母：字母/數字/_
    //不能是關鍵字

    /*數據類型：
        數值：
            整型：
                1.int
                2.short
                3.long
            非整型：
                1.float
                2.double
            !important example :
                2.5 + 5 / 2 = 4.5
                    since the computer thinks 2 is the int
                Solving : 
                2.5 + 5 / 2.0 = 5
                    to let the computer thinks 2 is a double/float
                2.5 + 5 / (float) 2 = 5
                    tell the computer that 2 is a float


        非數值：
            1.char
    */
    int salary = 2500; //薪水
    printf("The salary : %d\n",salary);
    float height = 150.0f;
    printf("The height is %.2f\n",height);  
    double radius = 2.5;
    double area = 3.141592653 * radius * radius;
    printf("Area = %.2lf\n",area);
    char ch = 'A'; //字符    
    //ASCII碼
    printf("The ASCII num = %d\n",ch);
    printf("The required signal is %c\n",ch);
    printf("---------------------------------------------");





/*
轉換字符總結：
    1. %d or %i (int/short/long) : 十進制整數
    2. %c(char) : 單個字符
    3. %s(string?) : 字符串
    4. %f(float) or %lf(double) : 浮點數，默認 6sig.fig.
        - 設置 sig.fig. 則在 % 之後增加 .x
        - 只會設置其顯示小數點，不會影響其精確數值
    5. %% : 打印一個'%'符號

*/

    
    return 0;
}
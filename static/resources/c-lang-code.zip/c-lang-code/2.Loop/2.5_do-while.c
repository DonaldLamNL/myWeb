#include <stdio.h>

int main()
{
    /* do-whi語法結構：
        do{
            code;
        }while(condition);
    */



// 取出數字
    int num = 12345;
    do{
        printf("%d\n",num%10);
        num /= 10;
    }while(num > 0);
    return 0;
}
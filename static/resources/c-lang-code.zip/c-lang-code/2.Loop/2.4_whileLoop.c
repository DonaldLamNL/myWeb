#include <stdio.h>

int main()
{
    /*
        while語法結構：
            while(condition){
                code;
                i++; (通常都會有，不然則無限循環)
            }
    */

//    int i=1;
//    while (i <= 10)
//    {
//        printf("Hello World %d\n",i);
//        i++;
//    }

//Question 1 -- AS
    // int i=1;
    // int sum=0;
    // while (i<=100)
    // {
    //     sum+=i;
    //     i++;
    // }
    // printf("The sum = %d",sum);


//Question 2 -- password
    // int password = 12345678; //密碼
    // int times=0; //輸入次數
    // int passwordEnter; //輸入的密碼

    // printf("Please enter the passward : ");

    // while (times != 3){
    //     scanf("%d",&passwordEnter);
    //     if (password == passwordEnter)
    //     {
    //         printf("You lock in sucessfully");
    //         break;
    //     }
    //     else if(password != passwordEnter && times == 2)
    //     {
    //         printf("Wrong password. You have no more chances");
    //         break;
    //     }
    //     else
    //     {
    //         times++;
    //         printf("Wrong password.\nYou have %d more times, please enter angin :",3-times);
    //     }
        
    // }

//Question 3 -- GS type 2
    double commonRatio = 1.25;
    double amountOfConsumption = 800;
    int years = 0;
    while (amountOfConsumption < 2000)
    {
        amountOfConsumption *= commonRatio;
        years++;
    }
    printf("The amount of consumption will attain 200 Billions in %d years",years);

   return 0;
}
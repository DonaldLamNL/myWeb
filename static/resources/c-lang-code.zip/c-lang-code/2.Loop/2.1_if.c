    /*
        語法結構：
            if(conditionA){
                code
            }
            if(conditionB){
                code
            }
            else{
                code
            }
    */
#include <stdio.h>

int main()
{
   double consumptionAmount;
   int discount;
   printf("Please enter the amount of consumption : ");
   scanf("%lf",&consumptionAmount);
   if (consumptionAmount >= 5000)
   {
       discount = 70;
   }
   else if(consumptionAmount >= 2000)
   {
       discount = 80;
   }
   else
   {
       discount = 90;
   }
   printf("You get a discount : %d%%off",discount);

    return 0;
}
#include <stdio.h>

int main()
{
    /*
        for語法結構：
            for(int i = 0; i < 9; i++)
            {
                code;
            }
    */
}
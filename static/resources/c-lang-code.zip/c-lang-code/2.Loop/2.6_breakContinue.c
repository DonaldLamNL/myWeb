#include <stdio.h>

int main()
{
    /* break vs continue
        - break :
            完全結束語句
            語句內之後的內容完全跳過
        - continue :
            直接回到語句開首
            語句內之後的內容完全跳過

        !important : reading notes
    */

// for loop
    printf("for loop\n");
   for(int i = 1; i <= 10; i++){
       printf("%d\n",i);
       if(i == 2){
           continue;
       }
       if (i == 5)
       {
           break;
       }    
   }

// do-while loop
    printf("do-while loop\n");
    int i = 1;
    do{
        if (i == 3)
        {
            i++;
            continue;
        }
        else if (i == 5)
        {
            break;
        }
        printf("%i\n",i);
        i++;
    }while(i <= 10);

//while loop
    printf("while loop\n");
    int j = 1;
    while (1)
    {
        if (j == 3)
        {
            j++;
            continue;
        }
        else if (j == 6)
        {
            break;
        }
        printf("%d\n",j);
        j++;
    }
    





    return 0;    
}
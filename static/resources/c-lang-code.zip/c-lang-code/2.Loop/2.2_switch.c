#include <stdio.h>

int main()
{
    /*
        switch語法結構：
            switch(expression){
                case 1-constantExpression:  //情況、案例
                    code;
                break;
                case 2:
                    code
                break;
                default:  
                    code;
            }
    */

   /*
        注意事項：
            - switch後的expression只可以是整形(int)或字符型(char)
            - case後的constantExpression不能相同
            - code可以有多條語句
            - break是用來終止結構，因此如果不存在的話後面的code也會執行
   */
   int month;
   
   printf("Please enter the month : ");
   scanf("%d",&month);
   switch (month){
       case 1:
            printf("The required month have 31 days");
       break;
       case 2:
            printf("The required month have 28 or 29 days");
       break;
       case 3:
            printf("The required month have 31 days");
       break;
       case 5:
            printf("The required month have 31 days");
       break;
       case 7:
            printf("The required month have 31 days");
       break;
       case 8:
            printf("The required month have 31 days");
       break;
       case 10:
            printf("The required month have 31 days");
       break;
       case 12:
            printf("The required month have 31 days");
       break;
       default:
            printf("The required month have 30 days");
   }
   return 0;
}
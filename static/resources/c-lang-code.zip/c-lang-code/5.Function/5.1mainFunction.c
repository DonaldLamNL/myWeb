#include <stdio.h>

int main(){
/*
    main函數：
        程序運行：執行從main函數開始，main函數裡包含其他函數，調用其函數後回到main函數

        定義函數時都是互相獨立的，函數裡不能嵌套其他函數
        函數可以互相調用，但不可調用main函數

    函數聲明：
        只是把函數名、參數的數量、參數的類型等信息傳遞給系統
        如 void name(int, int){}        //也是正確

    函數定義：
        把函數的功能確立起來



    函數種類：
        1. 標準函數
            如：printf(); scanf();
            不用自己定義

        //參數是用來傳遞數據的
        2. 無參數函數
            如：void name()        //傳遞void無
        結構：
            dataType name(){        //void就是沒有返回值
                statement;
                code;
            }

        3. 有參數函數
            如：void name(int x)        //傳遞函數值：x
        結構：
            dataType name(parameter with types){
                statement;
                code;
            }

        4. 空函數
            默認為  int name(){}
            所有沒有賦予類型的函數全都默認為int


        - 形式參數
            傳遞的是int/ double/ char etc...(變數)
            如果條用的實際參數是不同類型將其轉變為形式參數的類型
                如：調3.5去int x, x = 3;

        - 實際參數
            傳遞的數據是3.1415926(實數)
            可以是常量、變量或表達式，但要求他有確切的值，在調用的時候把其賦值給形參

        - 函數返回值
            return 把計算後的值返回去
            若不用返回值 (void name(){}) 則不用return

            return後面可以是一個表達式，只需要最後有一個確切的值就行
                return (x==y||z>y);

        - 全局變量 global variable
            定義在最外層，獨立與各個函數上


    ****如果函數的定義在main之前，則main裡不用聲明
        int name(int x){}
        main(){
            name(a);
        }

     OR    
        main(){
            int name(int y);
            name(a);
        }
        int name(){}
    
*/





    return 0;
}

#include <stdio.h>

int main()
{
    /* Array
        基本要素 :
            - 標示符 (名字)
            - 數組元素 (數據) 默認為0
            - 元素下標 (編號) 從0開始
            - 元素類型 (數據類型) 必須相同
        
        語法結構：
            - 一維數組 : 
                datatype arrayName[size]
    */
   
// 一維數組 Example
    // double score[5];
    // int input;
    // for (int i = 0; i < 5; i++)
    // {
    //     printf("Please enter the %dth score",i + 1);
    //     scanf("%lf", &score[i]);
    // }
    // for (int i = 0; i < 5; i++)
    // {
    //     printf("%.0lf\n", score[i]);
    // }
    
//Exercise_1-排大小
// 25 1 34 65 38
    int score;
    int length = 1;
    int array[10000];
    printf("Input the score and end with 0(which would not be counted\n");
    while (1)
    {
        printf("%dth data :",length);
        scanf("%d",&score);
        if (score == 0)
        {
            break;
        }
        
        array[length-1] = score; 
        length++;  
    }
    
    
    
    int timeOfChange ;
    while(1)
    {
        timeOfChange = 0;
        for (int i = 0; i < length - 2; i++)
        {
            if (array[i] < array[i+1])
            {
                array[i] += array[i+1];
                array[i+1] = array[i]-array[i+1];
                array[i] -= array[i+1];
                timeOfChange++;
            }           
        }
        if (timeOfChange == 0)
        {
            break;
        }
        
    }
    for (int i = 0; i < length-1; i++)
    {
        printf("%d ",array[i]);
    }
    
    

    return 0;
}
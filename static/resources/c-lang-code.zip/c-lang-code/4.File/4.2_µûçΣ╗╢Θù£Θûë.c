#include <stdio.h>

int main(){
    FILE *fp;
    char filename[20];

    int x;
    printf("執行函數：");
    scanf("%d", &x);

    char ch;
    printf("Please input the fileName :");
    scanf("%s", filename);

//

    if (x == 1)
    {
        if (!(fp = fopen(filename , "wt+")))
        {
            printf("Cannot open the file!\n");
        }
        printf("Please input the sentences you want to write: ");
        ch = getchar();
        ch = getchar();
        while (ch != EOF)
        {
            fputc(ch, fp);
            ch = getchar();
        }  
    }
    
    
//
    else if(x == 2){
        
        while(ch != EOF){
            if (!(fp = fopen(filename , "r")))
            {
                printf("Cannot open the file!\n");
            }
        
            ch = fgetc(fp);
            putchar(ch);
        }
    }
    fclose(fp);
    return 0;
}
    

#include <stdio.h>

int main(){
  FILE *fp;
  char ch;
  int b;
  int a[3][3] = {0};

  if (!(fp = fopen("01.Example.txt" , "r")))
    {
                printf("Cannot open the file!\n");
    }else{
        ch = getc(fp);
        if (ch == '1')b = 1;
        else b = 2;
        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < 3; j++)
            {
                ch = getc(fp);
                if (ch == '0') a[i][j] = 0;
                if (ch == '1') a[i][j] = 1;
                else if(ch == '2') a[i][j] = 2; 
                
                
            }
            
        }
        
        
    }

    printf("b = %d\n",b);
    for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < 3; j++)
            {
                printf("a[%d][%d] = %d\n",i,j,a[i][j]);
            }
        }
        
        

}
 ch = fgetc(fp);
            putchar(ch);
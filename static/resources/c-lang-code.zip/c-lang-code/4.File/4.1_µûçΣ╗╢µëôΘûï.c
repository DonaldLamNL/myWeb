#include <stdio.h>

int main(void) {
/*文件分類：
    A. 數據的組織形式
        1. ASCII文件
        2. 二進制文件

    B. 文件
        1. 文件的指針變量：
            FILE *fp;
                FILE : 類型結構體
                fp : 指向FILE的指針變量

        2. FILE Array
            FILE f[5];
                存放5個文件信息

    C. 文件的打開
        fopen函數
        結構：
            FILE *fp;
            fp = fopen("fileName", "openingWays");
                - the openingWays means "read" or "write" etc...

        說明：
            1. "r"，該文件必須已經存在，且只能從該文件讀出
            2. "w"  若文件不存在，則以指定的文件名建立該文件（創建文件）
                    若打開的文件已經存在，則將該文件刪除，重建一個新文件
            3. "a"  該文件必須存在
            4. 打開文件時，如果出錯則返回空指針'NULL'
                在文件中可以用來判別是否完成打開文件的工作
*/
    FILE *fp;
        if(! (fp = fopen("01.Example.txt","r"))){
            printf("ERROR");
        }else
        {
            printf("Open Success!");
        }
        



    return 0;
}
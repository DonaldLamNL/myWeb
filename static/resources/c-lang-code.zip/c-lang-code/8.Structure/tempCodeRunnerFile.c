    // struct Hero hero1;
    // hero1.id = 1;
    // strcpy(hero1.name, "德瑪西亞之力");
    // hero1.level = 5;
    // hero1.hp = 500;
    // hero1.mp = 100;
    // strcpy(hero1.skill, "大保健");
#include <stdio.h>

/*
    結構數組定義：
        struct Role
        {
            char* name;
            int age;
            char* job;
            char* skill;
        }roles[25];

    初始化：
        1.  按照上方所示方法定義，並在 main() 中
                struct Role roles[0] = {};

        2.  struct Role
            {
                char* name;
                int age;
                char* job;
                char* skill;
            }roles[] = {
                {"NAME1", AGE1, "JOB1", "SKILL1"},
                {"NAME2", AGE2, "JOB2", "SKILL2"}
            }




*/





int main(){




    return 0;   
}
#include <stdio.h>

    /*
        嵌套結構：

            struct Birth
            {
                int year;
                int month;
                int date;
            }birthday1;
            strcut Hero
            {
                char* name;
                struct Birth birthday1;
                char skill[50];
            };

        
        結構變量的初始化和賦值：
            1.  為各個變量賦值

            2.  struct Hero VAR = {"NAME",{YEAR, MONTH, DATE}, "SKILL"};
    */

//門派
struct Martial
{
    int id;
    char name[50];
    int count;
    int type;
};

struct Player
{
    int id;
    char name[50];
    char pass[50];
    char sex;
    struct Martial martial;
};


int main(){
    struct Player player = {1, "和尚", "123456", 'F', {1, "洛克薩斯", 500, 3}};
    printf("%s\t%s\n", player.name, player.martial.name);
    
    




    return 0;
}
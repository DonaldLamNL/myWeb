#include <stdio.h>

int main(){
/*
    結構體變量初始化
        結構：
            strcut student{
                int num;
                char *name;
                char sex;
            }student1, student2 = {1, "John", 'M'};

    結構體數組
        結構：
        1.  
            struct student{
                elements
            };
            在 main(){
                struct student boy[x];
                print boy1.element;
            }

        2.
            struct student{
                elements;
            }boy[3];


    結構體初始化
        結構：
        1.
            strcut student{
                char name[20];
                int age
            }boy[2] = {
                        {"John", 11},
                        {"May", 12}
                    };

        2. 
            struct student{
                elements
            };
            在 main(){
                struct student boy[x] = {{...},{...}};
            }

            
*/


    return 0;
}

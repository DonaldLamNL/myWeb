#include <stdio.h>
#include <string.h>

    /*
        結構體介紹：
            將不同類型的數據（元素elements）組合成一個整體
                如：學生{姓名，班別，學號，年齡，地址，成績}

        定義結構體：
            struct structName
            {
                //結構嚴肅
                DataType var1;
                DataType var2;
            };
            如：
                struct Hero
                {
                    char name[20];
                    int level;
                    char job[10];
                    char skill[10];
                };

            保存原理：
                與數組保存原理相似，是一個連續的空間：
                    第一個空間：name
                    第二個空間：level
                    第三個空間：job
                    第四個空間：skill
        注意：
            1. 結構定義並不預留內存      //結構本身不佔空間
            2. 結構定義一般放在程序開頭部分（頭文件聲明之後）   //千萬不要放在後面
            3. 結構定義僅用來描述結構的形式，使用結構需要聲明結構變量
                //能用的是變量，不是類型


    


        賦值方法：
            1. 直接賦值
                strcpy(hero1.name, "NAME");
                hero1.level = LEVEL;
                strcpy(hero1.job, "JOB");
                strcpy(hero1.skill, "SKILL");

            2. 類似於數組結構賦值
                struct Hero hero2 = {"NAME", LEVEL, "JOB", "SKILL"};

            3. 數組方式賦值，省略某些結構中元素
                struct Hero hero3 = {"NAME", .skill = "SKILL"};
            
            4. 指針賦值
                struct Hero
                {
                    char* name;
                    int level;
                    char* job;
                    char* skill;
                }
                int main(){
                    hero4.name = "NAME";
                    hero4.level = LEVEL;
                    hero4.job = "JOB";
                    hero4.skill = "SKILL";
                }
                優點：
                    不用使用strcpy();
                缺點：
                    如果需要讀取輸入進行賦值會出現 errors
                        因為 hero1.name 使用之前沒有內存
                            必須加上 hero1.name = (char*)malloc(50);
        結構定義：
            1.  struct Hero hero1;

            2.  struct Hero hero2 = {};

            3.  struct Hero
                {
                    char* name;
                    int level;
                    char* job;
                    char* skill;
                }hero1, hero2, hero3;

            4.  struct
                {
                    char* name;
                    int level;
                    char* job;
                    char* skill;
                }hero1, hero2, hero3;
*/

struct Hero
{
    int id;
    char* name;      //英雄名稱
    int level;
    int hp;
    int mp;
    char skill[50];     //英雄技能
};

int main(){
    //使用結構體：

    struct Hero hero1 = {2, "祥林嫂", 10, .skill = "瘋狂呢喃"};
    printf("The hero's name:\n");

    hero1.name = (char*)malloc(50);
    scanf("%s", hero1.name);


    printf("%d\t%s\t%d\t%d\t%s\n", hero1.id, hero1.name, hero1.level, hero1.hp, hero1.skill);

    return 0;
}

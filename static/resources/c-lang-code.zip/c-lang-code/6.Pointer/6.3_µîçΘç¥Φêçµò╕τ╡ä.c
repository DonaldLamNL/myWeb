#include <stdio.h>

int main(){
    /*
        數組介紹：
            存儲在一連串內存空間中
            數組名就是這塊連續空間的「首」個地址

            例子：
                double array[] = {1, 2, 3}
                double *ptr_array = & array[0];
                ptr_array == array;
        
        指針的算數運算：
            1. 遞增遞減 (++, --)
                *ptr_array++;       指針的移動
                    移動的單位是sizeof(T); //數據類型佔的字節 (double 8個)
                        double型指針一般佔4個字節


        總結：
            表示第 i+1 個元素：
                地址： 
                    &num[i];      OR        num[0] + i;
                值：
                    num[i]        OR        *(num + i);
            指針賦值：
                int * ptr_num = num;     OR     int ptr_num = &num[0];
            指針指向元素：  
                * ptr_num = &num[n];     OR     *ptr_num = num + 4;

    */
    double array[] = {98, 87, 65, 43, 76};
    printf("數組的首地址：%p\t數組的首元素地址：%p\n", array, &array[0]);
    double * ptr_array;
    ptr_array = array;
    for (int i = 0; i < 5; i++)
    {
        //訪問數組元素方式：
        //    printf("%.2lf\n", array[i]);
        //    printf("%.2lf\n", ptr_array[i]);
            printf("%.2lf\n", *(ptr_array + i));    //推薦，原指針沒有改變
        //    printf("%.2lf\n", *ptr_array++);        
            //不推薦，因為完成程序後其指針指向最後的元素，如果再作運用則需重置指針 ptr_array = array;

    }
    

    return 0;
}
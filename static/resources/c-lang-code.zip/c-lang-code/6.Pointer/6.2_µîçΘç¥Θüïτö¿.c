#include <stdio.h>

int main(){

    int num1 = 1024;
    int num2 = 2048;
    int * ptr1 = &num1;
    int * ptr2 = &num2;
    printf("num1的值是：%d\tnum1的地址是%p\n", num1, ptr1);
    printf("num2的值是：%d\tnum2的地址是%p\n", num2, ptr2);

    //將變量1的值 賦予變量2
    // num2 = num1; == *ptr2 = *ptr1;
    num1 = num2;
printf("===============================變量賦值給1後=================================\n");
    printf("num1的值是：%d\tnum1的地址是%p\n", num1, ptr1);
    printf("num2的值是：%d\tnum2的地址是%p\n", num2, ptr2);
    printf("變量變了，地址不變\n");


    ptr2 = ptr1;
printf("================================指針賦值給2後================================\n");
    printf("num1的值是：%d\tnum1的地址是%p\n", num1, ptr1);
    printf("num2的值是：%d\tnum2的地址是%p\n", num2, ptr2);
    printf("變量不變，地址變了\n");

printf("=============================改變指針2所指向的空間============================\n");

    *ptr2 = 1111111;
    printf("重新賦值後\n");
    printf("num1的值是：%d\tnum1的地址是%p\n", num1, ptr1);
    printf("num2的值是：%d\tnum2的地址是%p\n", num2, ptr2);

printf("當 指針1 的值賦予 指針2，指針2的值與 指針1 相同，因此指向的空間也與 指針1 相同，因此修改 指針2 對應的空間並非 空間2\n\n\n");
    //因為 ptr2 的值對應 ptr1，因此修改的是 ptr2 = ptr1 = num1 的值

    return 0;
}
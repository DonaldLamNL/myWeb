#include <stdio.h>

int main(){
    /*
        指針介紹：
            變量就是內存：就有內存地址。
            而保存內存地址就是指針，指針就是保存內存地址的變量
            內存地址就是16進制的變量

            int year;                   // int：數據類型  year：變量名             
            int* ptr_year;              // int*：指向指針（地址）的數據類型   ptr_year：變量名

            ptr_year = &year;           // 把 year 的地址取出來，賦值給 ptr_year
                                        // 換而言之，&：year的地址
            

        概念：
            變量          <----------- 指向 -----
            變量地址   ------>  指針（指針變量） --」

            變量：就是一個內存
            內存：就有一個內存地址
            指針：保存內存地址      的變量


        指針結構：
            數據類型* 指針變量名
            如：int* ptr_name;

            NULL：
              int* ptr_name = NULL;     //空指針
              指針的初值設為空，表示不指向任何地址
            
            int* ptr_name = EF123A;     //錯誤
                指針類型絕對不能取常數值
                指針類型一定是取地址符


        指針站位符：
            %p：打印指針類型數據
        打印指針：
            printf("%p", &num);
            printf("%p", prt_num);


        間接運算符：
            *ptr_num
                如果指針前面有 * ，則是尋找 ptr_num 這個地址所指向的空間
                * 就是佢該地址對應空間的值
                例如：*ptr_num == num;
                      ptr_num == num 的地址;

        指針的地址：
            int* ptr_num2 = &ptr_num;
                指針也是一個變量，因此指針也能指向一個指針



    */

    int num = 9;
    int* ptr_num = &num;
    printf("num變量的地址是： %p\n", ptr_num);        //%p打印指針變量

printf("=========================間接運算符============================");

    printf("*ptr_num對應的值為：%d\n", * ptr_num);           // * 是取值的意思
    *ptr_num = 99;             // ptr_num 地址對應的空間是 num；    == num = 99;
    printf("修改後：*ptr_num對應的值為：%d\n", * ptr_num);           


   




    return 0;
}
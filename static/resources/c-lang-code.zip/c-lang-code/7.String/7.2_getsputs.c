#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int getStrLength(char str[]){

    int count = 0;

    while(str[count] != '\0'){
        // if(str[count] == '\n') break;
        count++;
    }
    return count;
}

void getString(char str[], int count){

    fgets(str, count, stdin);

    //尋找\n
    
    char* find = strchr(str, '\n');     //返回 '\n' 字符的指針
    //如果沒有找到，就返回空指針 NULL
    if (find)
        *find = '\0';


    
    

}




int main(){
    /*
        gets：
            gets(names) == scanf("%s", names);
            puts(names) == printf("%s", names);
        嚴重問題：
            gets() 函數不對接受字符串的 buffer 進行邊界檢測     
                因此會把其他空間也給佔了，其他數組可能出現錯誤
            問題：
                fgets(); 默認最後一個元素設置為\0


        解決方案：
        fgets()     //真正用法其實是讀取文件
           
        結構：
            fgets(charName, fontSize, stdin);
            - 最多可讀取 fontSize-1 個字符，因為末尾作為\0
            如：
                fgets(names, 20, stdin);
                stdin：從標準輸入流中讀取 20個字節 到數組 names 中


        puts()：
            puts(names); == printf("%s", names);

    */

//     char name1[10];
//     fgets(name1, 10, stdin);

// printf("====================fgets()問題===================\n");
//     printf("%s\n", name1);abc

//     printf("The entered content:\n");
//     for (int i = 0; i < 15; i++)
//     {
//         printf("%d\n", name1[i]);       // \0 == 0(ASSIC)
//         if (name1[i] == 10)
//         printf("因為 fgets() 默認給最後一個元素設置為\n");
//     }
    
printf("=====================字符串長度====================\n");
    char name2[] = {'J','a','c','k','\0'};
    //fgets(name2, 5, stdin);                 //如果輸入abc，顯示的長度是4，因為 fgets() 默認最後一個元素為 '\n'
    getString(name2, 5);
    int length = getStrLength(name2);
    printf("strLength = %d\n", length);     //字符串長度為4，因為'\0'並不是字符串




    return 0;
}
#include <stdio.h>

int main(){
    /*
        簡介：
            字符串（Character String）：
                一個或者多個字符序列    如："Hello World."
                 "" 並不是字符串的一部分，僅用來告知編輯器：裡面的內容是字符串

            字符數組：
                C語言中，字符串是以字符數組存儲    如：｜H｜e｜l｜l｜o｜｜W｜o｜r｜l｜d｜.｜\0｜

             ** 每個儲存單元佔一個字節
                字符串的結尾一定是一個空字符 \0 （就是 ASSIC 的 0）
                    \0 != NULL
                    \0：字符串的終止符
                    NULL：空指針：是一個符號，不引用任何內容的內存地址


        定義字符串：
            1. 字符數組  char[3] = {'a','b','\0'};
            2. 字符串    char[] = "ab";
                - 所有 字符串 都是 字符數組     對！
                - 所有 字符數組 都是 字符串     錯！！！
        聲明字符數組：
            數組大小要比存儲的字符數 +1 因為編輯器會自動在字符串末尾添加 \0


        字符串的動態輸入方式：
            不需要加 & 符號
                如：
                    char words[20];
                    printf("Enter: ");
                    scanf("%s", words);     //No need the '&'
            因為字符串的數組本身就是一個地址，因此不用引入地址

    */   


    char name1[8] = {'J','a','c','k','s','o','n','\0'};
    char name2[] = "Jackson";
    printf("%s\t佔位：%lu\n", name1, sizeof(name1));
    printf("%s\t佔位：%lu\n", name2, sizeof(name2));

    return 0;
}
package B_Java面向對象初級;
/*
    A. JavaBean：Java寫成的可重用組建

    B. 所謂JavaBean，是指符合以下條件的類：
        · 類是公共的
        · 有一個無参的公共構造器
        · 有屬性，且有相應的get、set方法

 */
public class B16_JavaBean的使用 {
}

class CustomerA{
    private int id;
    private String name;

    public CustomerA(){

    }

    public void setId(int i){
        id = i;
    }
    public int getId(){
        return id;
    }
    public void setName(String n){
        name = n;
    }
    public String getName(){
        return name;
    }
}
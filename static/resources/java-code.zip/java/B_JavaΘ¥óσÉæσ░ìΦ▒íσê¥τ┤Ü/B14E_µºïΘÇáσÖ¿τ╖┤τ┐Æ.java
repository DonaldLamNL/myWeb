package B_Java面向對象初級;

public class B14E_構造器練習 {//三角形

    public static void main(String[] args) {
        triAngle t1 = new triAngle(2,3);
        System.out.println(t1.getArea());

    }
}

class triAngle{
    private double height;
    private double base;

    //一般設計的時候都會提供一個空参
    public triAngle(){}
    public triAngle(double h, double b){
        height = h;
        base = b;
    }

    public void setHeight(int h){
        height = h;
    }
    public double getHeight(){
        return height;
    }
    public void setWidth(int w){
        base = w;
    }
    public double getBase(){
        return base;
    }

    public double getArea(){
        return height * base / 2.0;
    }
}

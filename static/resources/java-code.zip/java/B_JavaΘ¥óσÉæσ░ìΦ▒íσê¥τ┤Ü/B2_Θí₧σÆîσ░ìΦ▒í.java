package B_Java面向對象初級;

/*
    一、 面向對象的兩個要素：
        類 Class：
                    一類事物的描述，是抽象和概念上的定義

        對象 Object：
            對象是實際存在的該類事物的每個個體，也稱為實例

    二、 類的成員
        設計類，就是設計類的成員

        類的內部結構：
            屬性 = 成員變量 = field = 域、字段
            方法 = 成員方法 = 函數 = method
*/
    class Person{
        //屬性
        String name;
        int age = 1;
        boolean isMale;

        //方法
        public void eat(){
            System.out.println("S/He can eat.");
        }
        public void sleep(){
            System.out.println("S/He can sleep.");
        }
        public void talk(String language){
            System.out.println("S/He can talk and the language is " + language);
        }
    }
/*
    三、 類的實例化（使用），即創建 類的對象
        創建類的對象 = 類的實例化 = 實例化類

    四、 類的使用（面向對象思想落地的實現）
        1. 創建類，設計類的成員
        2. 創建類的對象（new）
        3. 調用類的相關結構

    五、 如果創建了一個 類 的 多個對象，則每一個對象都獨立擁有一套類的對象（非static的）
        所以如果修改一個對象的屬性，其他對象的該屬性並不會受到影響

     */
    public class B2_類和對象{
        public static void main(String[] args) {
            //創建 類 的對象
            Person p1 = new Person();
            //Similar to Scanner sc = new Scanner(System.in);

            //調用對象的結構：屬性、方法
            //調用屬性格式："對象.屬性"
            p1.name = "John";
            p1.isMale = true;
            System.out.println(p1.name);

            //調用方法格式："對象.方法"
            p1.eat();
            p1.sleep();
            p1.talk("English");


            Person p2 = new Person();
            System.out.println(p2.name);  //null
            System.out.println(p2.isMale);  //false

            Person p3 = p1;
            System.out.println(p3.name);
            System.out.println(p3.isMale);
            p3.age = 13;
            System.out.println(p1.age);  //13   ***與C/C++不同
            //因為 p3 = p1 代表著將 p1 的保存地址值賦予給 p3，導致了 p1 和 p3 在堆空間指向了同一個對象實體
    /*
        六、 對象的內存解析


     */


        }
    }




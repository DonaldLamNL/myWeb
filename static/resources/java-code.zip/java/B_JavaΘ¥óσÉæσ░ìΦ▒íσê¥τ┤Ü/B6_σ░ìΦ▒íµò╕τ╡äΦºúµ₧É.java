package B_Java面向對象初級;
/*
    對象數組的內存解析：
        - 引用類型的變量：只可能存儲兩類值：null     或     地址值（含變量的類型）
 */
public class B6_對象數組解析 {
    public static void main(String[] args) {
        Student1[] stud = new Student1[5];

        /*
            內存運行：
                1. 在 棧 中聲明一個 stud 的變量
                2. 在 堆 中聲明一個長度5的數組      類似於聲明一個長度為5的表格而第一個數組的地址
                3. 把在 堆空間 數組的首地址值賦給棧空間中的變量 stud，讓棧空間的 stud變量 指向 堆空間中的數組實體
                4. 因為並沒有給數組的元素賦值，所以所有元素都是 null
        */
        System.out.println(stud[0]);

        /*
            數組本身是引用數據類型
            數組的元素是 自定義的 基本數據類型
            //意思就是數組裡的每一個元素都是 自定義的 數據類型

            因為數組元素並未賦值
         */

        stud[0] = new Student1();
        /*
            賦值過程：
                因為第一個位置是 Student1 類型，所以就要 new 一個Student1
            內存運行：
                new：在堆空間中重新造了一個對象（所以是有地址的）
                然後將其地址賦值給數組中的相對應位置
         */

        Student1 stud1 = new Student1();
        System.out.println(stud1);
        //引用類型的變量只可能存儲兩類值：null    或    地址值（包含變量類型）

        System.out.println(stud[1]);
        System.out.println(stud[1].score);
        /*
            因為數組的第二個元素 p[1] 為賦值，所以它是一個空指針，所以打印 p[1]的時候顯示 null空指針
            因為 stud[1] 沒有被創造為一個新對象，所以 stud[1] 不具備 Student1類 的屬性
            所以 stud[1].score 錯誤指向
         */
    }
}

class Student1{
    int number;
    int state;
    int score;
}
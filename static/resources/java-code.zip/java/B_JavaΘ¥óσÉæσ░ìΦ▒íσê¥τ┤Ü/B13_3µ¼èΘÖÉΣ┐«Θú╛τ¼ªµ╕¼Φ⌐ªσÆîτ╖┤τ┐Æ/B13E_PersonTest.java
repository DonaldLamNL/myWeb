package B_Java面向對象初級.B13_3權限修飾符測試和練習;

public class B13E_PersonTest {
    public static void main(String[] args) {
        B13E_Person p1 = new B13E_Person();
        System.out.println("Before assigning, age = " + p1.getAge());
        p1.setAge(12);
        System.out.println("After  assigning, age = " + p1.getAge());

        B13E_Person p2 = new B13E_Person("John", 21);
        System.out.println("name = " + p2.getName() + ", age = " + p2.getAge());

    }
}

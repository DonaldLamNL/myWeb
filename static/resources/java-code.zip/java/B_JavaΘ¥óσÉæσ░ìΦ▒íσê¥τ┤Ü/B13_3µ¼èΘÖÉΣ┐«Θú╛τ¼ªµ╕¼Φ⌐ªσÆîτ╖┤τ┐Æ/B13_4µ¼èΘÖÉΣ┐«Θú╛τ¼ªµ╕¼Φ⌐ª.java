package B_Java面向對象初級.B13_3權限修飾符測試;

import B_Java面向對象初級.B13_1封裝和隱藏;

public class B13_4權限修飾符測試 {
    public static void main(String[] args) {
        B13_1封裝和隱藏 order = new B13_1封裝和隱藏();
        order.orderPublic = 3;
        order.methodPublic();

        //order.orderDefault = 2;
        ////'orderDefault' is not public in 'B_Java面向對象初級.B13_1封裝和隱藏'.
        //// Cannot be accessed from outside package
        //order.methodDefault();
        ////'methodDefault()' is not public in 'B_Java面向對象初級.B13_1封裝和隱藏'.
        //// Cannot be accessed from outside package

    }

}

package B_Java面向對象初級.B13_3權限修飾符測試和練習;

public class B13E_Person {
        private int age;
        private String name;


        public B13E_Person(){
            age = 18;
        }
        public B13E_Person(String n, int a){
            name = n;
            age = a;
        }

        public void setAge(int a){
            if (a >= 0 && a <= 130){
                age = a;
            }else{
//                throw new RuntimeException("Invalid input.");
                System.out.println("Invalid input.");
            }
        }
        public int getAge(){
            return age;
        }

        public void setName(String n){
            name = n;
        }
        public String getName(){
            return name;
        }


}

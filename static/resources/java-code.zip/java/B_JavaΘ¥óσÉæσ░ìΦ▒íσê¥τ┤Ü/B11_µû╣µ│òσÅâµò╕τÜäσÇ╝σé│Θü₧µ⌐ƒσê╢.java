package B_Java面向對象初級;
public class B11_方法參數的值傳遞機制 {
/*
    關於普通變量的賦值
        - 如果變量是基本數據類型，此時賦值的是變量所保存的數據值
        - 如果變量是引用數據類型，此時賦值的是變量所保存的數據的地址值
*/
    public static void main(String[] args) {
        System.out.println("*************** 基本數據類型 ***************");
        int m = 10;
        int n = m;
        System.out.println("m = " + m + " n = " + n);
        n = 20;
        System.out.println("m = " + m + " n = " + n);

        System.out.println("*************** 引用數據類型 ***************");
        Order o1 = new Order();
        o1.orderId = 1001;
        Order o2 = o1;  //賦值的是地址的值，所以 o2和o1 都指向 堆空間中 同樣的對象實體
        System.out.println("o1 = " + o1.orderId + " o2 = " + o2.orderId);

        o2.orderId = 1002;  //因此修改 o2 指向的對象實體也是修改 o1 指向的對象實體
        System.out.println("o1 = " + o1.orderId + " o2 = " + o2.orderId);


/*
    方法參數的值傳遞機制：值傳遞
        1. 形参：方法定義時，聲明中小括號內的參數  public int name(int 形参){}
           實參：方法調用時，實際傳遞給形参的數據  name(實参)

        2. 值傳遞機制的描述
            如果參數是基本數據類型，此時實参賦給形参的是實参真實存儲的數據值
            如果參數是引用數據類型，此時實参賦給形参的是實参存儲數據的地址值
 */
        System.out.println("***************** 值傳遞 ******************");
        m = 10;
        n = 20;
        System.out.println("Before swapping, m = " + m + " n = " + n);
        B11_方法參數的值傳遞機制 test = new B11_方法參數的值傳遞機制();
        test.justSwap(m, n);    //實参
        System.out.println("After swapping, m = " + m + " n = " + n);

/*
    因為實参不再是傳遞一個數據值給形参，二者之間是相同變量名，但在不同方法中的兩個不同變量
    這裏傳入的實参是引用類型，所以傳入的是地址值，而形参接收的傳遞信息是實参的地址值而不是數據值
    所以形参指向實参所指向的實際對象，因此修改形参所指向的實際對象就等於修改實参所指向的實際對象
    相似於：
        Data d1 = new Data();
        Data d2 = d1;           d1 是一個引用數據類型，所以 d1 是賦了地址值給 d2
 */
        System.out.println("***************** 方法調換 *****************");
        Data data = new Data();
        data.m = 10;
        data.n = 20;
        System.out.println("Before swapping, m = " + data.m + " n = " + data.n);
        B11_方法參數的值傳遞機制 testMethod = new B11_方法參數的值傳遞機制();
        testMethod.swapThroughMethod(data);
        System.out.println("After swapping, m = " + data.m + " n = " + data.n);

    }

    public void justSwap(int m, int n){   //新的變量 - 形参
        int temp = m;
        m = n;
        n = temp;
    }

    public void swapThroughMethod(Data data){
        int temp = data.m;
        data.m = data.n;
        data.n = temp;
    }
}
class Order{
    int orderId;
}

class Data{
    int m;
    int n;
}
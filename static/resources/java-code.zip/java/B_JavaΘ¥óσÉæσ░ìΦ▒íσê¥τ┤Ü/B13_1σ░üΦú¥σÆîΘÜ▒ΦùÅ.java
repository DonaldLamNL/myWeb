package B_Java面向對象初級;
/*
    A. 設計者思路：「高內聚，低耦合」
        - 類的內部數據操作細節自己完成，** 不允許外部干涉 **
        - 僅對外暴露少量的方法用於使用
        --> 通過封裝性，把權限變得足夠小讓外界不能接觸
        ～ 把該隱藏的隱藏起，把該暴露的暴露出
    B. 封裝與隱藏：
        一、問題引入：
            - 當我們創建一個類的對象以後，我們可以通過 "對象.屬性" 的方式，對對象的屬性進行賦值
                這裏的賦值操作要受到屬性的數據類型和存儲範圍的制約，但除此之外沒有其他制約條件
            - 但實際問題中，我們需要給屬性賦值加入額外限制條件，這個條件就不能在屬性聲明的時候體現，因此通過方法添加條件
            - 同時我們需要避免用戶再使用 "對象.屬性" 的方式對屬性進行賦值，則需要將屬性聲明為 私有private
            --> 此時，針對屬性就體現了封裝性，相等於將屬性隱藏起來
        二、封裝性的體現：
            - 將類的屬性 私有化(private)，同時，提供 公共(public) 的方法來 獲取(getXxx)和設置(setXxx) 屬性的值
            *** 不等同於封裝性，只是封裝性的一個體現而已

    C. 封裝性拓展：
        1. 如上
        2. 不對外爆暴露的私有方法
        3. 單例模式

    D. 權限修飾符：
        - 封裝性的體現，需要權限修飾符的配合
        - Java規定的四種權限（從小到大排列）：private, 缺省(default), protected, public
            1. private      類內部
            2. default      同一個包
            3. protected    不同包的子類 --> 之後詳細講
            4. public       同一個工程
        - 四種權限可以用來修飾類的內部結構：屬性、方法、構造器、內部類
        - 具體的，四種權限都可以用來修飾內部結構
            修飾一個類：只能使用：缺省和public
            ie.
                private class Dog{}     //報錯，因為這已經是一個類，而private只能在類內部使用

    E. 總結封裝性：Java提供四種權限修飾符來修飾類及類的內部結構，體現類及類的內部結構在被調用時可見性的大小
 */

public class B13_1封裝和隱藏 {
    public static void main(String[] args) {
        Animal a = new Animal();
        //創建的時候 堆空間 也是有 legs屬性，但其權限很小，不能直接調用，但並不是不存在
        a.name = "大黃";
//        a.age = 1;
        a.setLegs(6);
        a.show();

        a.setLegs(-6);
//        a.legs(-4);     //編譯器知道有這個屬性，但是不能用
        a.show();
    }


    //修飾符的測試
        private int orderPrivate;
        int orderDefault;
        public int orderPublic;
        private void methodPrivate(){
            orderPrivate = 1;
            orderDefault = 2;
            orderPublic = 3;
        }
        void methodDefault(){
            orderPrivate = 1;
            orderDefault = 2;
            orderPublic = 3;
        }
        public void methodPublic(){
            orderPrivate = 1;
            orderDefault = 2;
            orderPublic = 3;
        }
}


class Animal{
    String name;
    private int age;
    private int legs;       //對這個屬性進行封裝，沒有對外暴露

    //對外不能直接修改變量屬性，轉而提供一個接口讓用戶通過那個接口修改變量屬性，在接口處設下條件
    //對於屬性的設置
    public void setLegs(int l){
        if (l >= 0 && l % 2 == 0){
            legs = l;
        }else{
            legs = 0;
            //或者拋出異常完善
        }
    }
    //對於屬性的獲取
    public int getLegs(){
        return legs;
    }

    //提供屬性 age 的 get和set 方法
    public  void setAge(int a){
        age = a;
    }
    public int getAge(){
        return age;
    }

    public void show(){
        System.out.println("name = " + name + ", age = " + age + ", legs = " + legs);
    }
}

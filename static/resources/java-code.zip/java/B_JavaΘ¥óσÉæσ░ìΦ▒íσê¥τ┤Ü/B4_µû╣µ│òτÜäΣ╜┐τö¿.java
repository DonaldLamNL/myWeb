package B_Java面向對象初級;
/*
    類中方法的聲明和使用

        1. 方法：描述類應該具有的功能：
            eg. Math類：sqrt()/ random() ...
                Scanner類：nextXXX() ...
                Arrays類：sort()/ binarySearch()/ toString()/ equals() ...

        2. 方法舉例         //組合：是否有返回值 & 是否有形参
            public void eat(){}                         //void 就是沒有返回值
            public void sleep(){}
            public String getName(){}                   //數據類型 String就是有返回值，返回字符串
            public String getNation(String nation){}

        3. 方法的聲明
            static, final, abstract 來修飾的方法 -->
            格式：
                權限修飾 返回值類型 方法名(形参列表){
                    方法體
                }

        4. 說明
            - 權限修飾符：目前默認方法的權限修飾符先都使用 public
                Java規定的權限修飾符：private, public, 缺省, protected -->封裝性

            - 返回值類型：    有返回值  vs.  無返回值：
                有返回值：
                    必須在方法聲明時，指定返回值的類型
                    同時，方法中需要使用 return 關鍵字來返回指定類型的變量或常量
                無返回值：
                    方法聲明時，使用 void 來表示
                    通常沒有返回值的方法中就不需要使用 return，或只能 return; 表示結束此方法的意思
                定義的時候該不該有返回值？   憑經驗

            - 方法名：屬於標識符，遵循標識符的規則和規範：見名知意

            - 形参列表：方法可以聲明 0個、1個、多個形参
                格式：數據類型1 形参1, 數據類型2 形参2, ...
                定義方法的時候要不要形参？   憑經驗

            - 方法體：方法功能的體現

        5. return關鍵字的運用：
            - 使用範圍：在方法體中
            - 作用：
                結束方法
                針對有返回值類型的方法，使用 return 數據; 方式返回所要的數據
            - 注意點：return 關鍵字後面不能有聲明執行語句

        6. 方法的使用：
            方法的使用中可以調用當前  類的屬性 和 方法
            特殊的：方法A中又調用方法A：遞歸方法
            ***方法中不可以定義其他方法（方法都是並列的）

 */
public class B4_方法的使用 {
    public static void main(String[] args) {
        Customer c1 = new Customer();
        c1.eat();
        c1.sleep(8);
    }
}

//客戶類
class Customer{
    String name;
    int age;
    boolean isMale;

    //方法
    public void eat(){
        System.out.println("Customer eats.");
    }
    public void sleep(int hour){
        System.out.println("Customer rested for " + hour + " hours.");
        eat();
    }
    public String getName(){
        if (age > 18) {
            return name;
        }else {
            return "Tom";
        }
    }
    public String getNation(String nation){
        String info = "The nation is " + nation;
        return info;
    }

    //禁止方法中定義方法：
//    public void info(){
//        public void swim(){
//
//        }
//    }
}

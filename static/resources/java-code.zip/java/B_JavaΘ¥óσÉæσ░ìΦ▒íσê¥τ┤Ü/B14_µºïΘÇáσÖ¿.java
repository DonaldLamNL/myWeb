package B_Java面向對象初級;
/*
    構造器Constructor  //構造方法

    一、 構造器的作用：
        1. 創建對象
        2. 初始化對象的信息（多為屬性）

    二、 說明：
        1. 如果沒有顯示定義類的構造器的話，則系統就提供一個空参的構造器（默認的構造器）
        2. 默認構造器 的權限取決於 類 的權限
        3. 定義構造器的格式：權限修飾符 類名(形参列表)
        4. 一個類中定義多個構造器，彼此構成重載
        5. 一旦我們顯示的定義了一個構造器之後，系統就不再提供默認的空参構造器
        6. 一個類中最少會有一個構造器

    三、 構造器與方法：構造器不是方法的一種（二者並列）
        功能不同：
            方法：有了對象，利用對象來調用方法的功能
            構造器：創造對象


 */

public class B14_構造器 {
    public static void main(String[] args) {
        //創建類的對象
        //變量類型 變量名 = new 構造器
        PersonA p = new PersonA();  //PersonA() 就是構造器
        p.eat();

        PersonA p1 = new PersonA("Tom");
        System.out.println(p1.name);
    }
}

class PersonA{
    //屬性
    String name;
    int age;

    //構造器   構造器的重載
    public PersonA(){
        System.out.println("Person()......");
    }
    public PersonA(String n){
        //創造對象的時候就把數值給賦了
        name = n;
    }
    public PersonA(String n, int a){
        name = n;
        age = a;
    }

    //方法
    public void eat(){
        System.out.println("Human can eat.");
    }

    public void study(){
        System.out.println("Human can study.");
    }
}

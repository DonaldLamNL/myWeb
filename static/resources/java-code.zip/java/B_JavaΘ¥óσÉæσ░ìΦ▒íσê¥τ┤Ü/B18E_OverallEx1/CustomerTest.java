package B_Java面向對象初級.B18E_OverallEx1;

public class CustomerTest {
    public static void main(String[] args) {
        Customer cust = new Customer("Jane","Smith");

        Account acct = new Account(1000, 2000, 0.0123);

        cust.setAccount(acct);

        cust.getAccount().deposit(100);
        cust.getAccount().withdraw(960);
        cust.getAccount().withdraw(2000);

        System.out.println("Customer " + cust.getFirstName() + " " + cust.getLastName());
        System.out.println("Account ID: " + cust.getAccount().getId());
        System.out.println("Balance is " + cust.getAccount().getBalance());
        System.out.println("annualInterestRate is " + cust.getAccount().getAnnualInterestRate() * 100 + "%");



    }
}

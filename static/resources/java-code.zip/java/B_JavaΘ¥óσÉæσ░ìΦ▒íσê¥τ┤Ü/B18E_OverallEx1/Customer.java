package B_Java面向對象初級.B18E_OverallEx1;

public class Customer {

    public static void main(String[] args) {

    }
    private String firstName;
    private String lastName;
    private Account account;

    public Customer (String f, String l){
        firstName = f;
        lastName = l;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public Account getAccount() {
        return account;
    }

    public void setAccount(Account account) {
        this.account = account;
    }
}


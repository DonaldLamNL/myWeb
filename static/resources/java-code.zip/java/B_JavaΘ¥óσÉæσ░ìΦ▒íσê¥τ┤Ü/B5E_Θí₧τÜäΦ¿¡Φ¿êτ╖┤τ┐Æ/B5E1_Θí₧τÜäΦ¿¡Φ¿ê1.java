package B_Java面向對象初級.B5E_類的設計練習;

public class B5E1_類的設計1 {     //class 189
    public static void main(String[] args) {
        PersonA p1 = new PersonA();

        p1.name = "Tom";
        p1.age = 18;
        p1.sex = 1;

        p1.study();
        p1.showAge();
        p1.addAge(2);
        p1.showAge();

        //*************************************
        PersonA p2 = new PersonA();
        p2.addAge(10);
        p2.showAge();

    }
}

class PersonA{
    //information
    String name;
    int age;
    int sex;

    //method
    public void study(){
        System.out.println("studying.");
    }
    public void showAge(){
        System.out.println("age: " + age);
    }
    public int addAge(int i){
        age += i;
        return age;
    }


}


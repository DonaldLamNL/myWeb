package B_Java面向對象初級.B5E_類的設計練習;

public class B5E3_類的設計3 {
    public static void main(String[] args) {
        System.out.println("Exercise 3.1:");
        B5E3_類的設計3 mth1 = new B5E3_類的設計3();
        mth1.method1();

        System.out.println("Exercise 3.2:");
        B5E3_類的設計3 mth2 = new B5E3_類的設計3();
        System.out.println("Area = " + mth2.method2());

        System.out.println("Exercise 3.3:");
        B5E3_類的設計3 mth3 = new B5E3_類的設計3();
        System.out.println("Area = " + mth3.method3(4,5));
    }

    public void method1(){
        for (int i = 0;i < 10;i++){
            for (int j = 0;j < 8;j++){
                System.out.print("* ");
            }
            System.out.println();
        }
    }

    public int method2(){
        for (int i = 0;i < 10;i++){
            for (int j = 0;j < 8;j++){
                System.out.print("* ");
            }
            System.out.println();
        }
        return 10 * 8;
    }

    public int method3(int m, int n){
        for (int i = 0;i < m;i++){
            for (int j = 0;j < n;j++){
                System.out.print("* ");
            }
            System.out.println();
        }
        return m * n;
    }

}


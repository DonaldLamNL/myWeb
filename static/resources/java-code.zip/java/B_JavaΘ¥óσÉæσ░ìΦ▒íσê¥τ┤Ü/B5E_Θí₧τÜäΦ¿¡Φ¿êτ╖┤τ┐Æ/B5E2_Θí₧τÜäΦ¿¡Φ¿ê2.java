package B_Java面向對象初級.B5E_類的設計練習;

public class B5E2_類的設計2 {
    public static void main(String[] args) {
        Circle c1 = new Circle();
        c1.radius = 2.5;
        System.out.println("Area1 = " + c1.findArea1());
        c1.findArea2();
    }
}

class Circle{
    double radius;

    //Have return value
    public double findArea1(){
        return radius * radius * Math.PI;
    }

    public void findArea2(){
        System.out.println("Area2 = " + radius * radius * Math.PI);
    }
}

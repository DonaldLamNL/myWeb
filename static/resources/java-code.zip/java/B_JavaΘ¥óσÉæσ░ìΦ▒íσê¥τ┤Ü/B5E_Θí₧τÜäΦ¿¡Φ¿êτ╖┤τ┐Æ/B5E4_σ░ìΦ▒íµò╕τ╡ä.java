package B_Java面向對象初級.B5E_類的設計練習;

public class B5E4_對象數組 {
    public static void main(String[] args) {
        //聲明一個student類型的數組
        student[] s = new student[20];
        for (int i = 0;i < s.length;i++){
            s[i] = new student();
            s[i].number = i + 1;
            s[i].state = (int)(Math.random() * (6 - 1 + 1) + 1);
            s[i].score = (int)(Math.random() * (100 - 0 + 1) + 0);
        }
        //問題一：打印所有學生的資料
        for(int i = 0;i < s.length;i++){
            System.out.println(s[i].studentInfo());
        }

        System.out.println('\n' + "*********************************");
        //問題二：打印三年級學生的資料
        for(int i = 0;i < s.length;i++) {
            if (s[i].state == 3) {
                System.out.println(s[i].studentInfo());
            }
        }

        System.out.println('\n' + "*********************************");
        //問題三：使用冒泡排序按照學生成績排序，打印其資料
        for (int i = 0; i < s.length - 1; i++){
            for (int j = 0; j < s.length - 1; j++){
                if (s[j].score > s[j + 1].score){
                    student temp = s[j];
                    s[j] = s[j + 1];
                    s[j + 1] = temp;
                }
            }
        }

        for(int i = 0;i < s.length;i++){
            System.out.println(s[i].studentInfo());
        }

    }
}

class student{
    int number;
    int state;
    int score;

    public String studentInfo(){
        return "Number: " + number + ", State: " + state + ", Score: " + score;
    }
}
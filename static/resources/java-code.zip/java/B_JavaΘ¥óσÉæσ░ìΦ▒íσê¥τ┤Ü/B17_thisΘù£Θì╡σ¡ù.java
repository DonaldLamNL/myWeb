package B_Java面向對象初級;
/*
    this關鍵字的使用：
        一、 可以用來修飾屬性、方法、構造器
            屬性和方法：
                - 把 this 理解為當前對象 --> this.name == p1.name （因為對象還未創造，用this代表對象）
                - 在類的方法當中，使用 "this.屬性"或"this.方法" 的方式，來調用當前對象的屬性或方法
                  通常情況下，我們都選擇省略 "this."
                  但是在特殊情況下，方法的形参和類的屬性重名時：
                  我們必須顯式的使用 "this.變量" 的方式表面此變量是屬性而非形参
            構造器：
                - 與上述相同，只不過 this 的定義修改為：當前創建的對象

        二、 this調用構造器
            1. 我們在類的構造器中，可以顯式的使用 "this(參數列表)" 的方式來，調用本類中指定的其他構造器
            2. 構造器中不能通過 "this(參數列表)" 的方式來調用自己
            3. 始終只造了一個對象，只不過是借用了其他構造器中的邏輯運算
       ***  4. 如果一個類中有 n個 構造器，則最多有 n-1 個構造器中調用其他構造器
       ***  5. 規定："this(參數列表)" 必須使用在當前構造器中的首行
               //constructor call must be the first statement in the constructor.
            6. 因為第5規定，一個構造器中只能聲明一個 "this(參數列表)"，來調用其他構造器
 */

public class B17_this關鍵字 {
    public static void main(String[] args) {

        PersonB p1 = new PersonB();

        p1.setAge(1);
        System.out.println(p1.getAge());

        p1.eat();
    }
}

class PersonB{
    private String name;
    private int age;

    public PersonB(){
        String info = "PersonB初始化時，需要考慮如下的1,2,3,4...（共40行代碼）     <-- Example";
    }
    //調用構造器，就是如果構造器初始化時，不同重載構造器的內容相同，運用this來調用構造器能省略繁瑣代碼
    public PersonB(String name){
        this();   //調用空参的  == 調用了 PersonB(){}
        this.name = name;
    }
    public PersonB(int age){
        this();
        this.age = age;
    }
    public PersonB(String name, int age){
        this(age);    //這樣等於調用了 Person(int age){}
        this.name = name;
        this.age = age;
    }
    public void setName(String name){
        //前面是屬性 = 後面是形参
        this.name = name;
    }
    public String getName(){
        return this.name;
    }
    public void setAge(int age){
        this.age = age;
    }
    public int getAge(){
        return this.age;
    }

    public void eat(){
        System.out.println("Human can eat.");
        this.study();
    }
    public void study(){
        System.out.println("Human can study.");
    }
}
package B_Java面向對象初級;
/*
    A. 方法的重載 Overload
        1. 重載的概念：
            在同一個類當中，允許存在一個以上的同名方法，只要他們的參數個數或者參數類型不同即可
            --> "兩同一不同"     //同一個類、相同方法名    參數列表不同： 參數個數不同/ 參數類型不同
        2. 重載的示範：
            Arrays類 中，重載的sort()/ binarySearch()/ copyOf()
        3. 判斷是否重載：
            跟方法的權限修飾符、返回值類型、形参變量名、方法體都沒有關係！！！
        4. 確定調用方法：
            因為方法名重複，因此不能通過方法名讓編譯器一個明確的指令調用哪一個方法
            所以要確定其調用的方法時：方法名 --> 參數列表
 */
    class OverLoad {
        public void getSum(int a, int b) {
            System.out.println("1");
        }
        public void getSum(double a, double b) {
            System.out.println("2");
        }
        public void getSum(String a, int b) {
            System.out.println("3");
        }
        public void getSum(int a, String b) {
            System.out.println("4");
        }

    /*
        public int getSum(int a, int b){
            return 0;
        }
        public void getSum(int b, int a){}
        private void getSum(int a, int b){}
    */

    }
public class B9_方法的重載 {
    public static void main(String[] args) {
        //A
        OverLoad ov = new OverLoad();
        ov.getSum(1,2);         // 1 OR 2   -->優先選擇匹配的參數類型，整型後是浮點型
    }

}

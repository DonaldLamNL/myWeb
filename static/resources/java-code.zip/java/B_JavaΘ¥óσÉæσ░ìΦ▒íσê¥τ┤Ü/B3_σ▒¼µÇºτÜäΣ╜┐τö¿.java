package B_Java面向對象初級;

/*
    屬性（成員變量） vs  局部變量

        1. 相同點：
            - 定義變量的格式是一樣的：數據類型 變量名 = 變量值;
            - 先聲明，後使用
            - 變量都有其對於的作用域（在這個區域以外就失效）

        2. 不同點：
            - 在類中聲明的位置不同
                屬性：直接定義在類的一對 {} 裡面
                局部變量：將聲明在方法內、方法形參、「代碼快內、構造器形参、構造器內部」的變量

            - 關於權限修飾符的不同
                屬性：可以在聲明變量的時，指名其權限，使用權限修飾符
                    常用的權限修飾符：private/ public/ 缺省/ protected（關於類的封裝性）
                    eg.
                        String xxx;     前面沒有寫別的就默認缺省
                局部變量：不可以使用權限修飾符

            - 默認初始化值的情況
                屬性：類的屬性，根據其類型，都有默認初始化值
                    整形 (byte, short, int, long)： 0
                    浮點型 (float, double)： 0.0
                    字符型 (char)：0 ('\U0000')
                    布爾型 (boolean)：false
                    引用數據類型 (類、數組、接口)：null
                局部變量：沒有默認初始化值
                    意味著在調用局部變量的時候必須顯示賦值
                    形参在調用的時候賦值即可

            - 在內存中加載的位置：
                屬性：加載到堆空間中  （非static    static就放在方法中）
                局部變量：加載到棧空間
*/

public class B3_屬性的使用 {
    public static void main(String[] args) {
        User u1 = new User();

        System.out.println(u1.name);
        System.out.println(u1.age);
        System.out.println(u1.isMale);

        u1.talk("English");     //調用的時候賦值

        u1.eat();

    }
}


class User {
    //屬性（成員變量）
    String name;
    public int age;
    protected boolean isMale;

    public void talk(String language) {  //language 就是形参
        System.out.println("We use " + language + " for communication.");
    }

    public void eat() {
        String food = "pizza";  //定義在方法內的變量 == 局部變量
        System.out.println("Americans like eat " + food + ".");
    }
}

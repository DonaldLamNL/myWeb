package B_Java面向對象初級;

public class B17E_this練習 {
    public static void main(String[] args) {
        Boy boy = new Boy("Tom", 21);
        boy.shout();

        Girl girl = new Girl("Dora", 18);
        girl.marry(boy);

        Girl girl1 = new Girl("Ada", 50);
        int compare = girl.compare(girl1);
        if (girl.compare(girl1) > 0){
            System.out.println(girl.getName() + " 比 " + girl1.getName() + " 大");
        }else if (girl.compare(girl1) < 0){
            System.out.println(girl.getName() + " 比 " + girl1.getName() + " 小");
        }else{
            System.out.println("一樣大");
        }

    }
}

class Boy{
    private String name;
    private int age;

    public Boy() {
    }
    public Boy(String name) {
        this.name = name;
    }
    public Boy(int age) {
        this.age = age;
    }
    public Boy(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public int getAge() {
        return age;
    }
    public void setAge(int age) {
        this.age = age;
    }

    public void marry(Girl girl){
        System.out.println("I want to marry " + girl.getName() + ".");
    }
    public void shout(){
        if (age >= 22){
            System.out.println("You can legally marry.");
        }else{
            System.out.println("You can't marry.");
        }
    }
}

class Girl{
    private String name;
    private int age;

    public Girl(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public void marry(Boy boy){
        System.out.println("I want to marry " + boy.getName() + ".");
        boy.marry(this);    //this當表當前對象，就是當前的girl
    }



    /*
        比較兩個對象的大小
        如果返回值是正數：當前對象大
        如果返回值是負數：當前對象小
        如果返回值是0：當前對象與形参對象相等
     */
    public int compare(Girl girl){
//        if (this.age > girl.age){     //方法對象的屬性 vs 形参對象的屬性
//            return 1;
//        }else if (this.age < girl.age){
//            return -1;
//        }
//        return 0;

        return this.age - girl.age;
    }




}
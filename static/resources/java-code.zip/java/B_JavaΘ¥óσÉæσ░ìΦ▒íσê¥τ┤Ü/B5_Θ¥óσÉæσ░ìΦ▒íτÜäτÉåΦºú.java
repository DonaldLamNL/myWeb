package B_Java面向對象初級;
/*
    A. 「萬事萬物皆對象」
        1. 在Java語言範疇中，我們都將功能、結構等封裝到一個類中，通過類的實例化來調用具體的功能結構
            > Scanner, String etc
            > File
            > Website resources, URL
        2. 涉及到Java語言與前端 Html、後端數據庫交互時，前後端的結構在Java層面交互時都體現為類、對象

*/


public class B5_面向對象的理解 {
}

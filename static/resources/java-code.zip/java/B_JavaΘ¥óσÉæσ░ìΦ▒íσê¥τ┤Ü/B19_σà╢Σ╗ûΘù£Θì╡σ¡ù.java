package B_Java面向對象初級;

import B_Java面向對象初級.B18E_OverallEx1.Account;
import B_Java面向對象初級.B18E_OverallEx2.Bank;

import java.util.*;

import static java.lang.System.*;
//表示我可以用 System類中 靜態的結構
import static java.lang.Math.*;

/*
    一、 關鍵字：package包
        1. 為了更好的實現項目中類的管理，所以提供包的概念，方便管理
        2. 使用 package 聲明類或接口所屬的包，聲明在原文件的首行
        3. package包，屬於標識符，所以要遵循標識符的命名規則、規範(全小寫：xxxyyyzzz)、「見名知意」
        4. 每 點"." 一次，就代表一層文件目錄
        補充：同一個包下，不同命名同名的接口、類
             不同的包下，可以命名同名的接口、類

    二、 MVC設計模式 - 為不同功能存在在不同的包裡面，以後會用到

    三、 關鍵字：import導入
        1. 在原文件中，顯式的使用 import 結構導入指定包下的類、接口
        2. 聲明在 package包 的聲明和類的聲明之間
        3. 如果要導入多個結構，則並列的寫出即可
        4. 可以使用 "xxx.*" 的方式表示導入xxx包下的所有接口
        5. 如果使用的類或接口是java.lang包下定義的，則可以省略import結構
        6. 如果使用的類或接口是本包下定義的，則也可以省略import結構
      * 7. 如果在原文件中，使用了不同包下同名的類，則必須有一個類需要以全類名的方式來顯示："packageName.className"
        8. 如果使用 "xxx.*" 方式表面可以調用xxx包下的所有結構，但如果使用的是xxx子包下的類，則仍需要顯式import

        9. import static：導入指定類或接口靜態結構：屬性/方法     //用得比較少





 */
public class B19_其他關鍵字 {
    public static void main(String[] args) {
        String info = Arrays.toString(new int[] {1,2,3});
        Bank bank = new Bank();

        ArrayList list = new ArrayList();
        HashMap map = new HashMap();

        Scanner s = null;

        System.out.println("Hello");

        Person p = new Person();

        Account acct = new Account(1000, 12000, 0.0125);
        B_Java面向對象初級.B18E_OverallEx2.Account acct1 = new B_Java面向對象初級.B18E_OverallEx2.Account(1000);

        Date date = new Date();
        java.sql.Date date1 = new java.sql.Date(1234567890965L);

        out.println("No need the System.");

        Math.round(123.345);
        round(123.345); //No need Math.


    }
}

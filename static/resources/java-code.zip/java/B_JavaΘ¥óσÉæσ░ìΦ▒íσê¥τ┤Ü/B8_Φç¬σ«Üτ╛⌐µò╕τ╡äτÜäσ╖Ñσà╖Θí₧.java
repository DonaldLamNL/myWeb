package B_Java面向對象初級;
/*
    自定義數組的工具類：




 */
public class B8_自定義數組的工具類 {


    //求數組的最大值
    public int getMax(int[] arr){
        int max = arr[0];
        for (int i = 1; i < arr.length; i++){
            if (arr[i] > max){
                max = arr[i];
            }
        }
        return max;
    }

    //求數組的最小值
    public int getMin(int[] arr){
        int min = arr[0];
        for (int i = 1; i < arr.length; i++){
            if (arr[i] < min){
                min = arr[i];
            }
        }
        return min;
    }

    //求數組的總和
    public int getSum(int[] arr){
        int sum = 0;
        for (int i = 0; i < arr.length; i++){
            sum += arr[i];
        }
        return sum;
    }

    //求數組的平均值
    public double getMean(int[] arr){
        return (double)getSum(arr) / arr.length;
    }

    //反轉數組
    public void reverse(int[] arr){
        for (int i = 0; i < arr.length / 2; i++){
            int temp = arr[i];
            arr[i] = arr[arr.length - i - 1];
            arr[arr.length - i - 1] = temp;
        }
    }

    //複製數組
    public int[] copy(int[] arr){
        return arr;
    }

    //數組排序
    public void sort(int[] arr){
        for (int i = 0; i < arr.length - 1; i++){
            for (int j = 0; j < arr.length - 1 - i; j++){
                if (arr[j] > arr[j + 1]){
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
    }

    //遍歷數組
    public void print(int[] arr){
        System.out.print("[");
        for (int i = 0; i < arr.length; i++){
            System.out.print(arr[i]);
            if (i != arr.length - 1) System.out.print(", ");
        }
        System.out.println("]\n");
    }

    //查找指定元素
    public int getIndex(int[] arr, int dest){
        for (int i = 0; i < arr.length; i++){
            if (arr[i] == dest){
                return i;
            }
        }
        return -99999;
    }
}

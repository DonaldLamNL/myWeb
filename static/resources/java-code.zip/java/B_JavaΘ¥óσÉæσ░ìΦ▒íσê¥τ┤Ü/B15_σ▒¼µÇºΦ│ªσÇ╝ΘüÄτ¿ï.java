package B_Java面向對象初級;
/*
    總結屬性賦值過程：
        一、 賦值的方法：
            1. 默認初始化
            2. 顯示初始化
            3. 構造器當中初始化
            （以上的賦值行為皆只執行一次）
            4. 通過 "對象.方法" 或 "對象.屬性" 賦值

        二、 以上操作的先後順序：
            1 -> 2 -> 3 -> 4
            數據值：取決於後面
*/

import jdk.swing.interop.SwingInterOpUtils;

public class B15_屬性賦值過程 {
    public static void main(String[] args) {
        UserA u = new UserA();

        System.out.println(u.age);

        UserA u1 = new UserA(2);

        u1.setAge(3);

        System.out.println(u1.age);
    }
}
class UserA{
    String name;
    int age = 1;

    public UserA(){

    }
    public UserA(int a){
        age = a;
    }

    public void setAge(int a){
        age = a;
    }

}
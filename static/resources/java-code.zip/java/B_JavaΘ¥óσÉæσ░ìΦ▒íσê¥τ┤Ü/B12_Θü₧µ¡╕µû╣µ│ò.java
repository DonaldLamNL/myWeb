package B_Java面向對象初級;
/*
    遞歸方法的使用了解：
        1. 遞歸方法：一個方法體內調用自身
            方法遞歸包含了一種隱式循環，它會重複執行某段代碼，但這段重複執行無須循環控制
            遞歸一定要向已知方向遞歸，否則就編成無窮遞歸，類似於死循環
        2.


 */

public class B12_遞歸方法 {
    public static void main(String[] args) {
        //例子一：計算1-100之間所有自然數的和
        int sum = 0;
        for (int i = 1; i <= 100; i++) {
            sum += i;
        }
        System.out.println(sum);

        B12_遞歸方法 testSum = new B12_遞歸方法();
        System.out.println(testSum.naturalSum(100));

        B12_遞歸方法 testProduct = new B12_遞歸方法();
        System.out.println(testProduct.naturalProduct(1000));

        B12_遞歸方法 testExerciseOne = new B12_遞歸方法();
        System.out.println(testExerciseOne.exerciseOne(10));

    }
    //例子二：計算1-100之間所有自然數的和
    public int naturalSum(int i) {
        if (i == 1){
            return 1;
        }else{
            return i + naturalSum(i - 1);
        }
    }

    //例子三：計算1-100之間所有自然數的乘積：n!
    public int naturalProduct(int n){
        if (n == 0){
            return 1;
        }else{
            return n * naturalSum(n - 1);
        }
    }

    //練習一：f(0) = 1, f(1) = 4, f(n+2) = 2 * f(n+1) + f(n)    Find f(10)
    public int exerciseOne(int x){
        if (x == 0) return 1;
        else if (x == 1) return 4;
        else return exerciseOne(x - 1) * 2 + exerciseOne(x - 2);
    }

    //練習二：斐波那契數列 ～ ie. f(n+2) = f(n+1) + f(n), f(0) = 1, f(1) = 1
    //練習三：漢諾塔問題
    //練習四：快排
    


}

package B_Java面向對象初級;
/*
    可變個數的形参：Varargs(variable number of arguments)
        允許直接定義能和多個實參想匹配的形参 --> 可以用簡單的方式來傳遞個數可變的實際參數

        1. JDK5.0新增的內容
        2. 具體使用
            - 可變個數形参的格式：數據類型...變量名(參數名)
            - 當調用可變個數形参的方法時，傳入的參數個數可以是 0個、1個、多個
                所有參數必須是該類型
            - 可變個數形参的方法與本類中方法名相同、形参不同的方法直接構成重載（可重載，不矛盾）
            - 可變個數形参的方法與本類中方法名相同、形参類型也相同的數組，二者不能共存（與數組重複）
            - 調用的時候就等同於調用數組，傳入的時候也可以傳入一個數組
            - 可變個數形参在方法的形参中，必須聲明在末尾（所以最多只能聲明一個可變形参）

 */

public class B10_可變形参的方法 {
    public static void main(String[] args) {
        B10_可變形参的方法 test = new B10_可變形参的方法();
        test.show("Hello");
        test.show("Hello", "World");
        test.show();

    }


    public void show(int i){
        System.out.println("int ... i");
    }
    public void show(String s){
        System.out.println("String s");
    }
    public void show(String ... strs){  //意思就是填幾個都行，都能識別
        System.out.println("String ... strs");
        for (int i = 0; i < strs.length; i++){
            System.out.print(strs[i] + " ");
        }
        System.out.println();
    }
//    public void show(String[] strs){} //不構成重載，顯示重複
        //因為JDK5.0之前使用數組，所以編譯器確認二者相同

}

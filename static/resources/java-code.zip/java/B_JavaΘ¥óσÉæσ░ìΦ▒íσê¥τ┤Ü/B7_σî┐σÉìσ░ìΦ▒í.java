package B_Java面向對象初級;
/*
    匿名對象的使用:
        理解：創建的對象沒有顯示的賦給一個變量名，即為匿名對象
        特徵：匿名對象因為沒有名，所以不能後續調用，只能調用一次
        使用：傳入匿名而參數變量接收匿名對象地址，變得可多次調用




 */

public class B7_匿名對象 {
    public static void main(String[] args) {
        Phone p = new Phone();  //創建一個對象——p
        System.out.println(p);  //因為賦值了，所以顯示地址

        p.sendEmail();
        p.playGame();

        //匿名對象：
        new Phone().sendEmail();
        new Phone().playGame();
        //他們兩個 不是！！！ 同一個對象
        //每 new 一次就等於創造一個新對象

        new Phone().price = 1999;
        new Phone().showPrice();    //0.0

        //***********************************
        PhoneMall mall = new PhoneMall();
        //匿名對象的使用
        mall.show(new Phone());
    }
}


/*
    雖然傳入的對象是匿名的，但是其地址保存在 形参 裡面
    所以在其 形参 中的方法是可以調用多次
    傳入的匿名對象已經賦值給 形参 的變量 p2中，所以已經不算匿名，因為棧空間中的形参 p2 能指向堆空間中傳入的匿名對象
 */
class PhoneMall{
    public void show(Phone p2){
        p2.sendEmail();
        p2.playGame();
    }
}

class Phone{
    double price;

    public void sendEmail(){
        System.out.println("Send an email.");
    }

    public void playGame(){
        System.out.println("Play games.");
    }

    public void showPrice(){
        System.out.println("The price of the Phone is " + price);
    }
}

package B_Java面向對象初級.B18E_OverallEx2;

public class Bank {
    private Customer[] customers;
    int numberOfCustomer;

    public Bank(){

    }

    public void addCustomer(String f, String l){
        Customer cust = new Customer(f, l) ;
        customers[numberOfCustomer++] = cust;
    }

    public int getNumberOfCustomer(){
        return numberOfCustomer;
    }

    public Customer getCustomers(int index){
        if (index >= 0 && index < numberOfCustomer) {
            return customers[index];
        }else {
            return null;
        }
    }
}

package B_Java面向對象初級.B18E_OverallEx2;

public class Account {
    private double balance;

    public Account(double init_balance){
        balance = init_balance;
    }

    public double getBalance(){
        return balance;
    }

    public void deposit(double amount){
        if (amount > 0){
            balance += amount;
            System.out.println("成功存入：" + amount);
        }
    }

    public void withdraw(double amount){
        if(amount > balance){
            System.out.println("餘額不足");
            return;
        }
        balance -= amount;
        System.out.println("成功取出：" + amount);
    }
}

package B_Java面向對象初級;

public class B8_自定義數組工具測試 {
    public static void main(String[] args) {
        B8_自定義數組的工具類 util = new B8_自定義數組的工具類();
        int[] arr = new int[]{32, 34, 5, 3, 54, 654, -98, 0, -53, 5};
        System.out.println("Maximum value = " + util.getMax(arr));
        System.out.println("Minimum value = " + util.getMin(arr));
        System.out.println("Sum = " + util.getSum(arr));
        System.out.println("Average value = " + util.getMean(arr));
        System.out.println("The position is in " + util.getIndex(arr, 5));

        util.sort(arr);
        System.out.print("After sorting, ");
        util.print(arr);
        System.out.println();


    }
}

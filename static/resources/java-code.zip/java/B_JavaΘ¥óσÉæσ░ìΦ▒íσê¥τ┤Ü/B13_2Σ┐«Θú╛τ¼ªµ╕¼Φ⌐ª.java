package B_Java面向對象初級;

public class B13_2修飾符測試 {
    public static void main(String[] args) {

        B13_1封裝和隱藏 order = new B13_1封裝和隱藏();

        order.orderDefault = 1;
        order.orderPublic = 2;
        //出了 B3_1封裝和隱藏 的類之後，私有的結構（屬性和方法）就不可以調用了
//        order.orderPrivate = 3;   //不可調用

        order.methodDefault();
        order.methodPublic();
//        order.methodPrivate();    //不可調用

    }
}

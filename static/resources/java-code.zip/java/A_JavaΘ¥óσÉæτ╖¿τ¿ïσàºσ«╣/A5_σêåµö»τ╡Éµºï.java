package A_Java面向編程內容;

public class A5_分支結構 {
    public static void main(String[] args) {
        java.util.Scanner sc = new java.util.Scanner(System.in);
        /*
            1. if-else

            2. switch-case
                格式：
                    switch(判斷變量){
                        case 變量值:
                            break;
                        case 變量值:
                            break;
                        default:        // == else
                    }
        */

        // if-else
        System.out.println("Input your height in cm.");
        double h = sc.nextDouble();
        if (h >= 120) {
            System.out.println("請購買全票");
        } else {
            System.out.println("請購買半票");
        }


        // switch-case
        System.out.print("Enter the grade:");
        String grade = sc.next();
        switch (grade) {
            case "A":
                System.out.println("Not less than 80 marks.");
                break;
            case "B":
                System.out.println("Not less than 70 marks.");
                break;
            case "C":
                System.out.println("Not less than 60 marks.");
                break;
            default:
                System.out.println("Lower than 60 marks");
        }
    }
}

package A_Java面向編程內容.Inty;

import javax.swing.*;
import java.util.PrimitiveIterator;
import java.util.Scanner;

public class mine {

    public static void main(String[] args) {
        int x;
        Scanner input = new Scanner(System.in);
        x = Integer.parseInt(input.next());

        switch (x) {
            case 1:
                System.out.println("You are right");
                break;

            case 2:
                System.out.println("You are smart");
                break;

            default:
                System.out.println("You are wrong");


                while (x < 10) {
                    x = x + 1;
                    System.out.println("x=" + x
                    );

                    while (x>=10){
                        System.out.println("x is not less than 10");
                    }
                }
        }
    }
}

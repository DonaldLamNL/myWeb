package A_Java面向編程內容.Inty;

import java.util.Scanner;

public class Healthy {
    public static void main(String[] args) {

        String n;
        System.out.println("What is your name?");
        Scanner input= new Scanner(System.in);
        n=input.next();

        String a;
        System.out.println("Please enter your age.");
        input= new Scanner(System.in);
        a=input.next();

        float h;
        System.out.println("Please enter your height(in m).");
        input = new Scanner(System.in);
        h = Float.parseFloat(input.next());

        float w;
        System.out.println("Please enter your weight(in kg.)");
        input = new Scanner(System.in);
        w = Float.parseFloat(input.next());

        h = h * h;
        float x;
        x = w / h;
        System.out.println("Your BMI is " + x);

        if (x < 18.5 && x > 0) {
            System.out.println("Oh "+n+", You are underweight");
        } else if (x >= 18.5 && x < 24) {
            System.out.println("You are healthy");
        } else if (x > 24) {
            System.out.println("Oh "+n+", You are overweight");
        } else {
            System.out.println("Hey, You are not a human");
        }


    }
}

package A_Java面向編程內容.Inty;

public class Ch3_2_常數
{
    public static void main(String[] args) {

        final double SPEED_OF_SOUND = 343.2;//宣告常數ie.PI & Speed of light(final double)
        final double PI = 3.1415926;
        double area,distance;
        double r=25.0;

        area=PI*r*r;
        distance=60*SPEED_OF_SOUND;
        
        System.out.println("Area="+area);
        System.out.println("Distance="+distance);
    }
}

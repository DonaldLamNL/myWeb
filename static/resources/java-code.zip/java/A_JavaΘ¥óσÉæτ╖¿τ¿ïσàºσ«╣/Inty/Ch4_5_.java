package A_Java面向編程內容.Inty;

public class Ch4_5_ {
    public static void main(String[] args) {
        java.util.Scanner sc = new java.util.Scanner(System.in);
        System.out.print("a=");
        double a = sc.nextDouble();
        System.out.print("b=");
        double b = sc.nextDouble();
        System.out.print("c=");
        double c = sc.nextDouble();

        boolean A = a > c && a > b;
        boolean B = b > a && b > c;
        boolean C = c > a && c > b;

        if (A == true) {
            System.out.println("a is maximum");
        } else if (B == true){
            System.out.println("b is maximum");
        }else if (C==true){
            System.out.println("c is maximum");
        }else{
            System.out.println("There are two maximum values");
        }
    }
}

package A_Java面向編程內容.Inty;

public class Ch5_5_APK {
    public static void main(String[] args) {
        java.util.Scanner sc = new java.util.Scanner(System.in);
        System.out.print("Enter the Chapter,Ch5_");
        int Ch = sc.nextInt();


//Ch5_4_乘數表
        if (Ch == 4) {
            int i, j;
            for (i = 1; i <= 9; i++) {
                j = 1;
                while (j <= 9) {
                    System.out.print(i + "*" + j + "=" + i * j + " ");
                    j++;
                }
                System.out.println("\n");
            }


//Ch5_5
        } else if (Ch == 5) {
            int i = 1;
            do {
                System.out.print("|" + i + "|");
                i++;
                if (i > 5) break;   //條件，如果i>5就stop(break)
            } while (true);     //true=一定會無限loop


//Ch5_6
        }else if (Ch==6){
            int i;
            for (i=1;i<=12;i++){
                if(i%2==1)continue;
                System.out.print("|"+i+"|");
            }





        }
    }
}


package A_Java面向編程內容.Inty;

import com.sun.jdi.connect.Connector;

import java.util.Scanner;

public class Inty_loop {
    public static void main(String[] args) {


        int c;
        System.out.println("Which type of loop?");
        Scanner input = new Scanner(System.in);
        c = Integer.parseInt(input.next());


        if (c == 1) {

            int a;
            System.out.print("a=");
            input = new Scanner(System.in);
            a = (int) Double.parseDouble(input.next());
            int b;
            System.out.print("b=");
            input = new Scanner(System.in);
            b = (int) Double.parseDouble(input.next());
            int n = 0;


            if (a > b) {
                while (a != b) {
                    a--;
                    b++;
                    n = n + 1;
                }
                System.out.print("number ogf loop = " + n);
                System.out.println(" and a=b=" + a);

            } else if (a < b) {
                while (a != b) {
                    a++;
                    b--;
                    n = n + 1;
                }

                System.out.print("number ogf loop(s) = " + n);
                System.out.println(" and a=b=" + a);
            }
        } else if (c == 2) {
            int x;
            System.out.print("x=");
            input = new Scanner(System.in);
            x= Integer.parseInt(input.next());

            String[] names = {"mark", "donald", "roy","tony","kitty","ada","peter","sally","betty"};

            for (int i=0;i<x;i++) {
                System.out.println(names[i]);
            }

        }

    }
}
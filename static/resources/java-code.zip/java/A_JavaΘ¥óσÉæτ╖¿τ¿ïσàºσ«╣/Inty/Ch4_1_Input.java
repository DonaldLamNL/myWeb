package A_Java面向編程內容.Inty;

public class Ch4_1_Input {
    public static void main(String[] args) {
        java.util.Scanner sc = new java.util.Scanner(System.in);
        System.out.println("Input your name.");
        String n = sc.nextLine();
        System.out.println("Input your result");
        int r = sc.nextInt();
        System.out.println("Input your height");
        double h = sc.nextDouble();
        System.out.println("Name:" + n);
        System.out.println("Result:" + r);
        System.out.println("Height:" + h);
    }
}

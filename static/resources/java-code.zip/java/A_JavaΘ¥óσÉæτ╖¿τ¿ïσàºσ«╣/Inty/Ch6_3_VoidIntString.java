package A_Java面向編程內容.Inty;

public class Ch6_3_VoidIntString {
    static double aaa(double c) {
        double f;
        f = (9 * c) / 5 + 32;
        return f;
    }

    public static void main(String[] args) {
        java.util.Scanner sc = new java.util.Scanner(System.in);
        System.out.println("Enter the temperature in celsius.");
        double c = sc.nextDouble();
        double f = aaa(c);
        System.out.println("The required temperature in Fahrenheit is " + f);
        int n[] = {1,2,3};
        System.out.println(n[1]);
    }
}

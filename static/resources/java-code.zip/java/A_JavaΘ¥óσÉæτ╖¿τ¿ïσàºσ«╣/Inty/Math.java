package A_Java面向編程內容.Inty;
class Math {
    int x,y,z;
    void a(){ System.out.println("Welcome to mathematics' world."); }

    public static void main(String[] args) {
        Math m=new Math();
        m.x=12;
        System.out.println("Hello");
        m.a();
        System.out.println(m.x);
    }
}

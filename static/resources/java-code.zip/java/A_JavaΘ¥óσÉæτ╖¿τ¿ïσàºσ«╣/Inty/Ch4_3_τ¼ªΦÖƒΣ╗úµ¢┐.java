package A_Java面向編程內容.Inty;

public class Ch4_3_符號代替 {
    public static void main(String[] args) {
        java.util.Scanner sc=new java.util.Scanner(System.in);
        System.out.println("現在時間(24進制小時)");
        int hour = sc.nextInt();

        String str=(hour>=12)?"PM":"AM";   //IF hour>=12就PM ELSE AM
        hour=(hour>=12)?hour-12:hour;      //IF hour>=12就-12 ELSE 不減

        System.out.println("The time now is "+hour+str);

    }

}

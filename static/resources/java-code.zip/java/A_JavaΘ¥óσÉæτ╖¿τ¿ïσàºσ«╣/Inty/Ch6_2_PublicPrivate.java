package A_Java面向編程內容.Inty;

public class Ch6_2_PublicPrivate {
    private static void bbb(char ln, int x) {
        int i;
        int j;
        for (i = 1; i <= x; i++) {
//            j = 1;
//            while (j <= i) {
//                System.out.print("@");
//                j++;
            for (j = 1; j <= i; j++) {
                System.out.print(ln);
            }
            System.out.print("\n");
        }
    }


    private static void aaa(int x) {
        int q;
        int sum = 0;
        for (q = 1; q <= x; q++) {
            sum += q;
        }
        System.out.println("Total number of '@' =" + sum);

    }


    public static void main(String[] args) {
        java.util.Scanner sc = new java.util.Scanner(System.in);
        System.out.print("請輸入三角形最大層數：");
        int x = sc.nextInt();
        Ch6_2_PublicPrivate.bbb('@', x);
        Ch6_2_PublicPrivate.aaa(x);
    }
}

package A_Java面向編程內容.Inty;

public class Ch3_3_進制和逸出字元 {
    //進制
    public static void main(String[] args) {
        double x = 0b11010010_01101001;   //(二進制+ 0b)(底線_不影響數值)
        double y = 047135;                //(八進制+ 0)
        double z = 0xECFF5E;              //(十六進制+ 0x)
        double e = 1.6e-3;                //(科學計算法+ e/E)

        System.out.println(x);
        System.out.println(y);
        System.out.println(z);
        System.out.println(e);


    }
}


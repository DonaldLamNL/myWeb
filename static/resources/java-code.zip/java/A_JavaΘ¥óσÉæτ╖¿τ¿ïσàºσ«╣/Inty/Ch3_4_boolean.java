package A_Java面向編程內容.Inty;

import java.util.Scanner;

public class Ch3_4_boolean {
    public static void main(String[] args) {
        double y;
        System.out.println("Which mode?");
        Scanner input = new Scanner(System.in);
        y = Double.parseDouble(input.next());
        double a;
        System.out.println("Input the number of a");
        input = new Scanner(System.in);
        a = Double.parseDouble(input.next());
        double b;
        System.out.println("Input the number of b");
        input = new Scanner(System.in);
        b = Double.parseDouble(input.next());

//遞減&遞進
//        a++;   //a+1
//        b--;   //b-1

        boolean A = a > b;  //false
        boolean B = a == b; //true
        boolean Y = y == 1;

        if (Y) {
            System.out.println("A " + A);
            System.out.println("B " + B);
            System.out.println("A || B " + (A || B));
            System.out.println("A && B " + (A && B));
            System.out.println("! " + !B);


        } else {
            System.out.println("y!=1");
        }

    }
}
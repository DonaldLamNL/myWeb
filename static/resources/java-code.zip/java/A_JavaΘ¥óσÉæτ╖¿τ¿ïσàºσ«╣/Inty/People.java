package A_Java面向編程內容.Inty;

public class People {

    void walk() {
        System.out.println("Person can walk");

    }

    String hasName(){                 //Since return的是String
        return "person can walk";
    }

    public static void main(String[] args) {
        new People().walk();
        System.out.println(new People().hasName());
    }
}

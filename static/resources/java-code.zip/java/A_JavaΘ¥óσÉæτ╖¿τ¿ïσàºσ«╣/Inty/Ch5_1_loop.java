package A_Java面向編程內容.Inty;

public class Ch5_1_loop {
    public static void main(String[] args) {
        java.util.Scanner sc = new java.util.Scanner(System.in);
        System.out.println("Choice 1: Switch to AS mode");
        System.out.println("Choice 2: Switch to GS mode");
        System.out.println("Choice 3: Calculate the facilitate(!)");
        System.out.println("Choice:");
        int M = sc.nextInt();

//for
        if (M == 1) {
            int a;
            int sum = 0;
            System.out.print("a0=");
            double i = sc.nextDouble();
            System.out.print("number of term=");
            int n = sc.nextInt();
            System.out.print("common different=");
            double d = sc.nextDouble();

            for (a = 0; a <= n; a++) {
                sum += i;
                i += d;
            }
            System.out.println("Sum=" + sum);

//while
        } else if (M == 2) {
            int a=0;
            int sum = 0;
            System.out.print("a0=");
            double i = sc.nextDouble();
            System.out.print("number of term=");
            int n = sc.nextInt();
            System.out.print("common ratio=");
            double r = sc.nextDouble();
            while (a <= n) {
                sum += i;
                i *= r;
                a+=1;
            }

            System.out.println("Sum=" + sum);

//do+while
        } else if (M == 3) {
            System.out.print("x=");
            int i = sc.nextInt();
            if (i==0){
                System.out.println("0!=1");
            }else if (i<0){
                System.out.println(i+"! "+"is undefined");
            }else{
            double x=i;
            double sum = 1;

            do {
                sum*=x;
                x--;
            }while(x>0);
            System.out.println(i+"!="+sum);}

//while vs do+while
//while在於開首，先判定後執行
//do在於結尾，先執行後判定

        }
    }
}

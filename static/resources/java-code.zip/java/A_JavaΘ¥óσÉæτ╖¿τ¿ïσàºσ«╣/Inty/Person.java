package A_Java面向編程內容.Inty;

//class=object   //void
public class Person {
    //Person的屬性
    String name;
    int age;
    String height;

    //Inty.Person's method
    void eat() {
        System.out.println("Inty.Person can eat");
    }

    //void=避免返回
    public static void main(String[] args) {

        Person inty = new Person();
        //Create new object
        inty.age = 18;
        inty.eat();
        System.out.println(inty.age);
    }
}

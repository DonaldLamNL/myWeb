package A_Java面向編程內容;

public class A4_符號 {

    public static void main(String[] args) {


    /*
        A. 賦值運算符
            =  +=  -=  *=  /=  %=
            int i = 10;
            //連續賦值
            int i1 = i2 = 10;

            ++ --
            n++;    //先運算，後加一
            ++n;    //先加一，後運算
    */
            int n = 10;
            n += n++ + ++n;         //n = n + (n++) + (++n)
            // n + (n++)    == 10 + 10 AND n++;     n = 11;
            //+ ++n         == 20 + (++11)  == 20 + 12
            System.out.println(n);  // == 32
    /*
        B. 比較運算符
            1. ==  !=  <  >  <=  >=

            2. instanceof  檢查類型是否正確
                eg. "Hello" instanceof String   == true
    */
            int i = 10;
            int j = 20;
            System.out.println(i == j);
            System.out.println(i = j);
            //意思是，首先將 j 的值賦值給 i
            //然後再 print i
    /*
        C. 邏輯運算符
            &    邏輯與
            &&   短路與
            |    邏輯或
            ||   短路或
            !    邏輯非
            ^    邏輯異與       !二者是否相同 true^true == false  true^false = true

     */
    /*
        D. 位運算符
            <<   左移
            >>   右移
            >>>  無符號右移
            &    與運算
            |    或運算
            ^    異或運算
            ~    取反運算

     */
    }
}

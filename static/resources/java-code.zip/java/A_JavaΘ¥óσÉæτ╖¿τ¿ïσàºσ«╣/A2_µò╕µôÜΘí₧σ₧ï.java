package A_Java面向編程內容;

public class A2_數據類型 {
    public static void main(String[] args) {
    /*
        I. 變量 Variable
            1. 變量概念
                - 內存中的一個存儲區域
                - 包括變量類型、變量名和存儲值
                - 格式：數據類型 變量名 = 變量值;
            2. 數據類型(字節)
                A. 基本數據類型
                    - 數值型：
                        整數類型：byte(1), short(2), int(4), long(8)
                        浮點類型：float(4), double(8)
                    - 字符型：char(2)
                        char NAME = 'VALUE';
                    - 布爾型：boolean
                        boolean NAME = true / false;
                B. 引用數據類型
                    - 類 class
                    - 接口 interface
                    - 數組 array[]

            3. 字符集
                - ASCII code
                - Unicode
                - UTF-8 (popular)
    */
        long l = 12345L;
        System.out.println(l);
        //如果沒有加 L 則直接默認 int 型
        long l1 = 1234567898765432L;
        System.out.println(l1);
        //如果超出 int 型範圍則報錯

        float f = 123.4F;
        float f1 = (float)123.4;
        //float 一定要加F
        System.out.println(f + "and" + f1);
        double f2 = 1234.567;
        //double 則不需
        System.out.println(f2);

        //整型常量默認為 int 型
        //浮點型默認為 double 型
        byte b = 12;
        //b = b + 1;    //報錯，因為 1 為 int 型
        int i = b + 1;  //這樣就正確

    /*
        II. String 字符串
            1. 不是基本數據類型，是引用數據類型
            2. 定義/ 格式：String 變量名 = "變量值";
    */
        String s1 = "Hello World";
        String s2 = "a";
        System.out.println(s1 + s2);

        String s3 = "";
        //char c = '';  //報錯

        String studentID = "Student ID is: ";
        int num = 1155159171;
        System.out.println(studentID + num);

    /*
        III. boolean 布爾值
            值有true 和 false 的值；


     */
        boolean b1 = true;
        System.out.println(b1);
        String info = s2 + b1;
        System.out.println(info);   //布爾值可以與字符串連接
        //System.out.println(l + b1); //報錯，布爾值不能與數值型連接
    /*
         + ：
            計算符號：
                如果都是常量或數值型，則為計算符號+
            連接符號：
                如果途中有字符串，則為連接符號
    */
        int i2 = 1;
        int i3 = 99;
        String s4 ="Hello";
        System.out.println(i2 + i3 + s4 + i2 + i3);
        //因為編譯器是從左到右編譯
        //  所以左邊還沒遇到 字符串 則 + 為運算符號
        //  當遇到 字符串 後的所有 + 則變為連接符號





    }
}

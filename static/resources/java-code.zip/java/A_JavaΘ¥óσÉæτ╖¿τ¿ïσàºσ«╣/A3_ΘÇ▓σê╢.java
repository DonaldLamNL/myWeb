package A_Java面向編程內容;

public class A3_進制 {
    public static void main(String[] args){
    /*
        計算機底層為 二進制 形式
        計算機常用進制：
            1. 二進制
                格式：以 0b / 0B 開頭
                如 0b123 = 83;
            2. 十進制
                格式：從 1-9

            3. 八進制
                格式：以 0 開頭
                如 0123 = 83;

            4. 十六進制
                格式：以 0x / 0X 開頭




     */
        int b1 = 0b0101011;
        System.out.println("二進制的0101011，十進制 = " + b1);
        int b2 = 0123;
        System.out.println("八進制的123，十進制 = " + b2);
        int b3 = 0x123Af;
        System.out.println("十六進制的123Af，十進制 = " + b3);
    }
}

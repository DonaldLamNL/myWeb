package A_Java面向編程內容;

import java.util.Scanner;

public class A1_基本概念 {
    public static void main(String[] args) {

    /*
        A. 標識符 Identifier
            - 英文字母，0-9，_或 $ 組成
            - 數字不可以開頭
            - 不可使用關鍵字和保留字，但能包括
            - Java中嚴格區分大小寫，長度無限制
            - 標識符不能包括空格

        B. print
            System.out.print();       //打印後不隔行
            System.out.println();     //打印後自動隔行

        C. scan
            使用 Scanner類 或許不同類型變量
            1. 導包： import java.util.Scanner;
                因為 Scanner類 在其他的包裝裡，所以要先導進 class 才能運用
            2. Scanner的實例化
                聲明Scanner 變量名 = new Scanner(獲取變量地址)
            3. 調用Scanner類的相關方法，來獲取指定類型的變量
                後去指定類型：變量名.next類型();
                獲取字符串：變量名.next();
    */
        //聲明Scanner 變量名 = new Scanner(獲取變量地址)
        Scanner sc = new Scanner(System.in);
        System.out.print("Input an integer = ");
        int num = sc.nextInt();
        System.out.println(num);
        System.out.print("Next input string = ");
        System.out.println(sc.next());
        System.out.print("Third input string = ");
        String s = sc.next();
        char c = s.charAt(0);
        System.out.println(c);


    }
}

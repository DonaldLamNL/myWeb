package A_Java面向編程內容.Mosh;

public class Random {
    public static void main(String[] args) {
        do {
            System.out.println((int) (Math.random() * 100000));
        }while ((int) (Math.random() * 100000)!=0);
    }
}

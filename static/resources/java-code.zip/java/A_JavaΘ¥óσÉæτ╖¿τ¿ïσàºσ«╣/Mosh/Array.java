package A_Java面向編程內容.Mosh;

import java.util.Arrays;

public class Array {
    public static void main(String[] args) {
        System.out.println("ARRAY");

        System.out.println("ToString");
        int[] n1 = new int[5];   //new int[quantity of number in array]
        n1[0]=12;
        System.out.println(Arrays.toString(n1));

        int[] n2 = {1,2,3,4,5};
        System.out.println(Arrays.toString(n2));
        System.out.println("\n");

        System.out.println("Sort");
        int[] n3 = {2,4,5,3,1};
        System.out.println("Before sorting: "+Arrays.toString(n3));
        Arrays.sort(n3);
        System.out.println("After sorting: "+Arrays.toString(n3));
        System.out.println("---------------------------------------------------------");

        System.out.println("MATRIX");
        System.out.println("DeepToString");
        int[][] A=new int[2][3];    //2*3Matrix
        A[0][0]=3;
        System.out.println(Arrays.deepToString(A));

        int[][] B={{1,2,3},{2,3,4}};
        System.out.println(Arrays.deepToString(B));





    }
}
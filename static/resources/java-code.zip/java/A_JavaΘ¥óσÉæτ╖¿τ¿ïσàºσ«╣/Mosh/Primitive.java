package A_Java面向編程內容.Mosh;

public class Primitive {
    //基本數據類型(byte short int  long float double char boolean)
    public static void main(String[] args) {
        System.out.println("Create constant value with 'final'");
        final double PI = 3.1415;     //Always use capital letters to name the constant
        System.out.println("pi=" + PI);
        System.out.println("Because 'final' is added that the constant pi can't change");
        System.out.println("----------------------------------------------------------------------------");

        System.out.println("Change String to Integer");
        String x = "1";
        String a = "1.2";
        int y = Integer.parseInt(x) + 2;
        System.out.println("x+2=" + y);
        double z = Double.parseDouble(x) + 12.2;
        System.out.println("a+12.2=" + z);
        System.out.println("----------------------------------------------------------------------------");

        System.out.println("Round method");
        System.out.println("n=134.4543");
        double n = 134.4543;
        System.out.print("\n");

        System.out.println("Round up[Math.ceil]");
        int n1 = (int) Math.ceil(n);
        System.out.println(n1);
        System.out.println("Round down[Math.floor]");
        int n2 = (int) Math.floor(n);
        System.out.println(n2);
        System.out.println("Round off[Math.round]");
        int n3=(int)Math.round(n);
        System.out.println(n3);
        System.out.print("\n");

        System.out.println("Maximum[Math.max]");
        int b = Math.max(1, 123);
        System.out.println(b);
        System.out.println("Minimum[Math.min]");
        double c = Math.min(23432.34, 23.234);
        System.out.println(c);
        System.out.println("\n");

        System.out.println("Random number");
        double r1 = Math.random()*100;
        System.out.println(r1);
        double r2 = (int)Math.round(Math.random()*100);


    }
}

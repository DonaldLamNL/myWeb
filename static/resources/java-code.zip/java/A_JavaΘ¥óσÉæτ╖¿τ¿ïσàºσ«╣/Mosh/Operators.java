package A_Java面向編程內容.Mosh;

public class Operators {


    //Boolean
    static void bool() {
        int x = 20000;
        String output = x > 10000 ? "First" : "Economy";
        System.out.println(output);
    }


    //IfStatement
    static void ifElse() {
        int x = 20000;
        if (x > 10000) {
            System.out.println("First");
        } else System.out.println("Economy");
    }

    //IfStatement
    static void ifStatement() {
        String role = "admin";
        if (role == "admin") {
            System.out.println("You're an admin");
        } else if (role == "moderator") {
            System.out.println("You're a moderator");
        } else {
            System.out.println("You're a guest");
        }
    }

    //SwitchStatement
    static void SwitchStatement() {
        String role = "admin";
        switch (role) {
            case "admin":
                System.out.println("You're an admin");
                break;
            case "moderator":
                System.out.println("You're a moderator");
                break;
            default:
                System.out.println("You're a guest");
        }
    }


    public static void main(String[] args) {
        System.out.println("By using ifElse function");
        ifElse();
        System.out.println("By using a simple function");
        bool();
        System.out.println("-----------------------------------------------" + "\n");

        ifStatement();
        System.out.println("Switch statement: switch+case+break+default");
        SwitchStatement();
        System.out.println("-----------------------------------------------" + "\n");

    }
}

package A_Java面向編程內容.Mosh;

import jdk.swing.interop.SwingInterOpUtils;

import java.awt.*;
import java.util.Date;

public class Reference {
//Date Point String

    public static void main(String[] args) {
        Date date=new Date();
        System.out.println(date);
        System.out.println("------------------------------------------------");

        Point A=new Point(1,1);
        Point B=A;
        A.x=2;
        System.out.println("In Reference");
        System.out.println(B);
        System.out.println("However:");
        int x=1;int y;
        y=x;
        x=2;
        System.out.println("In Primitive");
        System.out.println("x="+x+" y="+y);
        System.out.println("------------------------------------------------");

        System.out.println("Function of String");
        String m="Hello World"+"!!";
        System.out.print("\n");

        System.out.println(m);
        System.out.println("Function1-contains:Do m contain 'Hel'?");
        System.out.println(m.contains("Hel"));
        System.out.print("\n");

        System.out.println("Function2-length:How many characters?");
        System.out.println(m.length());
        System.out.print("\n");

        System.out.println("Function3-StartWithAndEndWith:Do m start with 'Hel' and end with '**' ?");
        System.out.println(m.startsWith("Hel")+" and "+m.endsWith("**"));
        System.out.print("\n");

        System.out.println("Function4-IndexOf:What is the index of 'o' and 'sk'?");
        System.out.println(m.indexOf("o")+" and "+m.indexOf("sk"));
        System.out.print("\n");

        System.out.println("Function5-Replacement:Replace '!' by '*'");
        System.out.println(m.replace("!","*"));
        System.out.println("(How ever the replace function does not change the string as the strings in java is immutable.");
        System.out.println("The replace function is going to return a new string.)");
        System.out.println("For example, "+m);
        System.out.print("\n");

        System.out.println("Function6-LowerCaseOrUpperCase");
        System.out.println("LowerCase: "+m.toLowerCase());
        System.out.println("UpperCase: "+m.toUpperCase());
        System.out.println("\n");

        System.out.println("Function7-Trimming");
        String newm="    Hello World"+"!!   ";
        System.out.println("Before trimming: "+newm);
        System.out.println("After trimming: "+newm.trim());
        System.out.println("\n");

        System.out.println("Function8-backslash'\\'");
        System.out.println("If we want to add some symbols.");
        System.out.println("Original: "+m);
        System.out.println("After: "+"Hello \"World\""+"!!");
        System.out.println("After: "+"Hello \\World\\"+"!!");

    }
}

package A_Java面向編程內容.Mosh;

import java.util.Scanner;

public class Exercise1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter:");
        int enter = sc.nextInt();
        if (enter % 5 == 0 && enter % 3 == 0) {
            System.out.println("FizzBuzz");
        } else if (enter % 5 == 0) {
            System.out.println("Fizz");
        } else if (enter % 3 == 0) {
            System.out.println("Buzz");
        } else {
            System.out.println(enter);
        }
    }
}

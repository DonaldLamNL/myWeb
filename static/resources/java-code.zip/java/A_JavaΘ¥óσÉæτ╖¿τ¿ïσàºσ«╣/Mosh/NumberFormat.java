package A_Java面向編程內容.Mosh;

public class NumberFormat {
    public static void main(String[] args) {
        java.text.NumberFormat percentage = java.text.NumberFormat.getPercentInstance();
        String result = percentage.format(0.1);
        System.out.println(result);
    }
}

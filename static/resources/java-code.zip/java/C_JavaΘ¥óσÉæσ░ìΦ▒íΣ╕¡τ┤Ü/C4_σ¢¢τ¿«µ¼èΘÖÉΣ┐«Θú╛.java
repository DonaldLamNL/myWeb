package C_Java面向對象中級;

import C_Java面向對象中級.C4_四種不同修飾演示.Order;

public class C4_四種權限修飾 {
    public static void main(String[] args) {
        Order order = new Order();
        order.orderPublic = 1;
        order.methodPublic();

        //不同包下的普通類（非子類）要使用 Order類，不可以調用聲明為 private、缺省、protected的屬性或方法

    }
}

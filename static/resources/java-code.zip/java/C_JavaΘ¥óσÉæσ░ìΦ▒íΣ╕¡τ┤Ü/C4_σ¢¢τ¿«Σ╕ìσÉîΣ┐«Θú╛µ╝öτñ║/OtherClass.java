package C_Java面向對象中級.C4_四種不同修飾演示;

public class OtherClass {
    public static void main(String[] args) {
        Order order = new Order();

        order.orderDefault = 1;
        order.orderProtected = 2;
        order.orderPublic = 3;

        order.methodDefault();
        order.methodProtected();
        order.methodPublic();

        //同一個包中的其他類不可以調用 類中私有的屬性、方法
//      order.orderPrivate;
//      order.methodPrivate;

    }
}

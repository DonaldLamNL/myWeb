package C_Java面向對象中級.C4_四種不同修飾演示.SubOrder;

import C_Java面向對象中級.C4_四種不同修飾演示.Order;

public class SubOrder extends Order {
    public void method(){
        orderProtected = 1;
        orderPublic = 2;

        methodProtected();
        methodPublic();

        //不同包的子類中，不能調用 類中 聲明為 private或缺省 屬性的結構或方法
//      orderDefault = 3;
//      orderPrivate = 4;
//      methodDefault();
//      methodPrivate();

    }
}

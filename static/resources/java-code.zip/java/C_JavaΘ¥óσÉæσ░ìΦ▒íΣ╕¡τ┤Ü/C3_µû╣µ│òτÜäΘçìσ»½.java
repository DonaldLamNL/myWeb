package C_Java面向對象中級;
/*
    方法的重寫 override/ overwrite
        一、 介紹：
            - 子類繼承父類以後，可以對父類中同名同參數的方法進行覆蓋操作
        二、 應用：
            - 重寫以後，當創建子類對象以後，通過子類對象調用子父類中同名同參數的方法時，實際執行的是子類重寫父類的方法

        三、 規定：
            1. 方法的聲明：權限修飾符 返回值類型 方法名(形参列表) throws異常類型 { 方法體 }
            2. 約定俗成：子類中的叫重寫的方法，父類中的叫被重寫的方法
                - 子類重寫的 方法名和形参列表 ，與父類被重寫的 方法名和形参列表 相同！！
                - 子類重寫的方法修飾符 不小於 父類被重寫的方法修飾符（可相等）
                    > 特殊情況：子類不能重寫父類中聲明為 private 的方法
            3. 返回值類型：
                - 父類被重寫的方法的返回值類型是 void，則子類重寫的方法的返回值類型也只能是 void
                - 父類被重寫的方法的返回值類型是 A類型，則子類重寫的方法的返回值類型可以是 A類或A類的子類
             ** - 父類被重寫的方法的返回值類型是 基本數據類型，則子類重寫的方法的返回值必須是相同的基本數據類型
            4. 異常類型：
                - 子類重寫的方法拋出的異常類型 不大於 父類被重寫的方法拋出的異常類型（具體以後再講）
    *******************************************************************************************
            5. 靜態非靜態：
                - 子類和父類中的同名同參數方法，要麼都聲明為 非static（考慮重寫），要麼都聲明為 static（不叫重寫了）




    面試題：區分方法的重載和重寫
 */
public class C3_方法的重寫 {
    public static void main(String[] args) {
        StudentA s1 = new StudentA("computer science.");
        s1.eat();
        s1.walk(10);
        System.out.println("******************************");
        s1.study();

        PersonA p1 = new PersonA();
        p1.eat();
    }
}



class PersonA{
    String name;
    int age;

    public PersonA() {
    }

    public PersonA(String name, int age) {
        this.name = name;
        this.age = age;
    }

    static void eat(){
        System.out.println("父類：Eating.");
    }
    public void walk(int distance){
        System.out.println("父類：Walking for " + distance + " km.");
        show();
        eat();
    }
    private void show(){
        System.out.println("父類：I am a human.");
    }
    public Object info(){
        return null;
    }
    public double info1(){
        return 1.0;
    }
}



class StudentA extends PersonA{
    String major;

    public StudentA() {
    }

    public StudentA(String major) {
        this.major = major;
    }

    public void study(){
        System.out.println("子類：Major is " + major);
    }

    //對父類中的 eat 方法進行重寫
    static void eat(){
        System.out.println("子類：Student should eat more nutritious food.");
    }
    public void show(){
        System.out.println("子類：I am a student.");
    }
    public String info(){
        return null;
    }
//  public int info1(){     //incompatible return type
//      return 1;
//   }


    @Override
    public void walk(int distance) {
        super.walk(distance);
    }
}
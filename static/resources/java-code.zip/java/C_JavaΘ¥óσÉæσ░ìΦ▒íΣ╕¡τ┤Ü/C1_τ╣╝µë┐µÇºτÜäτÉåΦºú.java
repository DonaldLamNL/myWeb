package C_Java面向對象中級;
/*
    面向對象特徵二：繼承性extends：     //Control + H 查看繼承列表
        一、 繼承性的好處：why?
            1. 減少代碼的冗余，提高代碼的復用性
            2. 便於功能的擴展（直接將子類共同的功能賦予給父類再繼承）
            3. 為之後的多態性的使用，提供前提

        二、 繼承性的格式：class A extends B{}
             A：子類、派生類     subclass
             B：父類、超類、基類     superclass

            - 體現：一旦子類A繼承父類B以後，子類A中就獲取了父類B中聲明的所有屬性和方法
            - 特別：父類中聲明為 私有private 的屬性或方法，子類繼承父類以後，仍然認為獲取了父類中的私有結構
                 只因為封裝性的影響，使得子類不能直接調用父類的結構而已。
            - 子類繼承父類以後，子類還可以聲明自己特有的屬性或方法：實現功能的擴展
            - 子類和父類的關係不同於集合和子集的關係

        三、 Java繼承性的規定：
            1. 一個類可以被多個子類繼承
            2. java類的單繼承性：一個類只能有一個父類（不允許多重繼承）
            3. 子父類是一個相對的概念：可多層繼承
            4. 子類直接繼承的父類：直接父類，間接繼承的：間接父類
            5. 子類繼承父類以後，就獲取了直接父類和所有間接父類聲明的屬性和方法

        四、 Object類
            - 如果沒有顯式的聲明一個類的父類的話，這個類就繼承 java.lang.Object類
            - 所有的java類都直接或間接繼承 java.lang.Object類（除java.lang.Object類）
            - 意味著所有的Java類都具備 java.lang.Object類 聲明的功能
 */

public class C1_繼承性的理解 {
    public static void main(String[] args) {
    //一、
        Person p1 = new Person();
//      p1.age = 1;
        p1.eat();
        System.out.println("*******************************");

        Student s1 = new Student();
        s1.eat();
//      s1.sleep();

        s1.setAge(12);
        System.out.println(s1.getAge());
        s1.breath();

        Creature c1 = new Creature();
        c1.breath();
    }
}



//三、
class Creature{
    public void breath(){
        System.out.println("Breathing.");
    }
}



//一、
class Person extends Creature{
    String name;
    private int age;

    public Person(){

    }
    public Person(String name, int age){
        this.name = name;
        this.age = age;
    }

    public int getAge(){
        return age;
    }
    public void setAge(int age){
        this.age = age;
    }

    public void eat(){
        System.out.println("Eating.");
        sleep();
    }
    //二、
    private void sleep(){
        System.out.println("Sleeping.");
    }
}



//一、
class Student extends Person{
//  String name;
//  int age;
    String major;

    public Student(){

    }
    public Student(String name, int age, String major) {
        this.name = name;
//      this.age = age;
        setAge(age);
        this.major = major;
    }



//  public void eat(){
//      System.out.println("Eating.");
//  }
//  public void sleep(){
//      System.out.println("Sleeping.");
//  }
    public void study() {
        System.out.println("Studying.");
    }
    public void show() {
        System.out.println("name: " + name + ", age: " + getAge());
    }
}


package C_Java面向對象中級;
/*
    關鍵字的使用：
        一、 介紹：
            super可以理解為：父類的
            super可以用開調用：屬性、方法、構造器

        二、 使用：屬性
            - 可以在子類的方法或構造器中使用 "super.屬性" 或 "super.方法" 的方式，顯式的調用父類中聲明的屬性或方法
              但通常情況下習慣省略 "super."
            > 特殊情況：當子類和父類中定義了同名的屬性時，我們要想在子類中調用父類中聲明的屬性
                        則必須顯式的使用"super.屬性"的方式，表明調用的是父類中聲明的屬性
            使用：方法
            > 特殊情況：當子類重寫了父類中的方法以後，我們想再子類的方法中調用父類中被重寫的方法時
                        則必須顯式的使用"super.方法"的方式，表明視同的是父類中被重寫的方法

        三、 super調用構造器
            - 我們可以在子類的構造器中顯式的使用 "super(形参列表)" 的方式，調用父類中聲明的指定的構造器
            - "super(形参列表)" 的使用，必須聲明在子類構造器的首行！
         ** - 我們在類的構造器中，針對於 "this(形参列表)" 或 "super(形参列表)" 只能二選一
            - 在構造器的首行，沒有顯示的聲明 "this(形参列表)" 或 "super(形参列表)"，則默認調用父類中空参的構造器：super();
         ** - 在類的多個構造器中，至少有一個類的構造器使用了"super(形参列表)"，調用父類構造器




 */

public class C5_super關鍵字 {
    public static void main(String[] args) {
        StudentB s1 = new StudentB();
        s1.show();
        s1.study();

        System.out.println("*****************************************************");
        StudentB s2 = new StudentB("Tom", 22, "computer science");
        s2.show();

        System.out.println("*****************************************************");
        StudentB s3 = new StudentB();

    }
}

class PersonB{
    String name;
    int age;
    int id = 1001;

    public PersonB(){
        System.out.println("默認為：super();");
    }
    public PersonB(String name){
        this.name = name;
    }
    public PersonB(String name, int age) {
        this.name = name;
        this.age = age;
    }


    public void eat(){
        System.out.println("父類：eating.");
    }
    public void walk(){
        System.out.println("父類：walking.");
    }
}



class StudentB extends PersonB{
    String major;
    int id = 1002;

    public StudentB(){

    }
    public StudentB(String major){
        super();
        this.major = major;
    }

    public StudentB(String name, int age, String major) {
//      this.name = name;
//      this.age = age;
        super(name, age);
        this.major = major;
    }

    public void eat(){
        System.out.println("子類：Student should eat more nutritious food.");
    }
    public void study(){
        System.out.println("子類：Student learn new knowledge.");
        this.eat();
        super.eat();
    }
    public void show(){
        System.out.println("name : " + this.name + ", age : " + super.age);
        System.out.println("Student ID = " + this.id);
        System.out.println("ID = " + super.id);
    }


}
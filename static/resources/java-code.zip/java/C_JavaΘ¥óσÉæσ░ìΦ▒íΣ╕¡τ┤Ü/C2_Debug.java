package C_Java面向對象中級;
/*
    調試程序：
        1. System.out.println().

        2. Eclipse - Debug調試功能




 */

public class C2_Debug {
    public static void main(String[] args) {
        int i = 10;
        int j = 20;
        System.out.println("i = " + i + " j = " + j);
        System.out.println("Hello");
        System.out.println(i);
        System.out.println(j);
    }
}

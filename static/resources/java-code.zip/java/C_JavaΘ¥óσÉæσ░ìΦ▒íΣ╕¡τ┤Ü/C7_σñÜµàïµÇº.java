package C_Java面向對象中級;
/*
    面向對象特徵三：多態性 Polymorphism
    ********** 281

        一、 理解：一個事物的多種型態

        二、 何謂多態性：
            - 對象的多態性：父類的引用指向子類的對象

        三、 多態的使用：虛擬方法調用
            - 有了對象的多態性以後 (Person p = new Man();)
                我們在編譯期，只能調用父類中聲明的方法
                但是在運行期，實際執行的是子類重寫父類的方法
        **  - 總結：編譯看左邊，運行看右邊

        四、 多態性的使用前提：
            1. 要有類的繼承關係 (Person p = new Man();)
            2. 要有方法的重寫   (否則沒有必要 new 一個子類)

        五、 對象的多態性，只適用於方法，不適用於屬性 //編譯和運行都看左邊

        六、 虛擬方法調用：
            子類中重寫了父類中的方法，在多態情況下，將此時父類的方法稱為虛擬方法
            父類數據賦給它的不同子對象，動態調用屬於子類的該方法，
        **  這樣的方法調用在編譯期間是無法確認 <-- 這也表明多態性是一個運行時行為
 */
public class C7_多態性 {
    public static void main(String[] args) {

        PersonD p1 = new PersonD();
        p1.eat();

        Man man = new Man();
        man.eat();
        man.age = 25;
        man.earningMoney();

        System.out.println("***************************************************************");
        //對象的多態性：父類的引用指向子類的對象
        PersonD p2 = new Man();

        PersonD p3 = new Woman();
        //多態的使用：當調用子父類同名同參數的方法是，實際執行的是：子類重寫父類的方法：虛擬方法調用
        p2.eat();
        p2.walk();

//      p2.earningMoney();  //Cannot resolve method 'earningMoney' in 'PersonD'

        System.out.println("***************************************************************");
        System.out.println(p2.id);  //父類的屬性



    }
}



class PersonD{
    String name;
    int age;

    int id = 1001;

    public void eat(){
        System.out.println("Eating.");
    }
    public void walk(){
        System.out.println("Walking.");
    }
}

class Man extends PersonD{

    boolean isSmoking;

    int id = 1002;

    public void earningMoney(){
        System.out.println("Man would earn money for his family.");
    }
    public void eat(){
        System.out.println("Man should eat more meat.");
    }
    public void walk(){
        System.out.println("Man should walk confidently.");
    }
}



class Woman extends PersonD{
    boolean isBeautiful;

    public void goShopping(){
        System.out.println("Woman always go shopping.");
    }
    public void eat(){
        System.out.println("Woman should eat fewer for keeping fit.");
    }
    public void walk(){
        System.out.println("Woman should walk more beautiful.");
    }
}
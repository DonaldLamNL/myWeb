package C_Java面向對象中級;

import java.sql.Connection;

/*
    多態性的使用舉例




 */
public class C8_多態性的使用 {

    public static void main(String[] args) {
        //例子一：
        C8_多態性的使用 test = new C8_多態性的使用();
        test.func(new Dog());
        test.func(new Cat());
    }

    //例子一：
    public void func(Animal animal) {   //Animal animal = new Dog();
        animal.eat();       //調用animal，運行dog
        animal.shout();
    }

    //如果沒有多態性，則需要創造以下方法：
    public void func(Dog dog) {
        dog.eat();
        dog.shout();
    }

    public void func(Cat cat) {
        cat.eat();
        cat.shout();
    }
}


//例子一：
class Animal{
    public void eat(){
        System.out.println("Animal can eat.");
    }
    public void shout(){
        System.out.println("Animal will shout.");
    }
}

class Dog extends Animal{
    public void eat(){
        System.out.println("Dogs eat dogs' food.");
    }
    public void shout(){
        System.out.println("woof-woof-woof");
    }
}

class Cat extends Animal{
    public void eat(){
        System.out.println("Cats eat fish.");
    }
    public void shout(){
        System.out.println("meow-meow-meow");
    }
}


//例子二：
class Order{
    public void method(Object obj){

    }
}


//例子三：
class Driver{

    public void doData(Connection conn){//conn = new MySqlConnection();  //conn = new OracleConnection();
        //規範的步驟去操作數據
//      conn.method1();
//      conn.method2();
//      conn.method3();
    }
}
function test(){
    console.log('test--c')
}

module.exports = test
import moduleA from "./module/moduleA.js"
import {moduleB, moduleC} from './module/moduleB.js'

console.log(moduleA.getName())
console.log(moduleB.getName())
console.log(moduleC.getName())
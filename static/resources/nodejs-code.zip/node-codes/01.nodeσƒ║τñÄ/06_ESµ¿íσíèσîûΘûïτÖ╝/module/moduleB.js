const moduleB = {
    getName(){
        return 'moduleBB'
    }
}
const moduleC = {
    getName(){
        return 'moduleCC'
    }
}

export {
    moduleB,
    moduleC,
} 
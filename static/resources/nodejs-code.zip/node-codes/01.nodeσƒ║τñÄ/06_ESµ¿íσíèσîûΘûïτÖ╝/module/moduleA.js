const moduleA = {
    getName(){
        return 'moduleAA'
    }
}

export default moduleA
console.log('Hello World')

function test(){
    console.log('test')
}

test()

// console.log(document)
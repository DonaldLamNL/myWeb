function test(){
    console.log('test--b')
}

console.log(firstLetterUpper('hello'))

function test(){
    console.log('test--c')
}

_init()
import App from './App.vue'

new Vue({
    el:'#root',
    template:`<App></App>`,
    components:{App}
})
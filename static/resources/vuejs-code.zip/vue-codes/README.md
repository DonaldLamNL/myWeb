# Run the codes
1. Install vue environmant and build vue-cli@3
2. Rename the folder as 'src' and place it into the root